const welcomeMessage = document.getElementById('welcomeMessage')
const nameInput = document.getElementById('userNameInput')
const saveBtn = document.getElementById('saveButton')
const clearBtn = document.getElementById('clearButton')
const todo = document.getElementById('to-do')

const STORAGE_KEY = 'nameValue'

saveBtn.addEventListener('click',()=>{
    const nameValue = nameInput.value.trim()

if (nameValue){
    localStorage.setItem(STORAGE_KEY, nameValue)
    displayWelcomeMessage(nameValue)
    alert(`Ten cua ban la "${nameValue}" da duoc luu`)
} else {
    alert('Vui long nhap ten')
}
})

clearBtn.addEventListener('click',()=>{
    const nameValue = nameInput.value.trim()


    localStorage.removeItem(STORAGE_KEY)
    nameInput.value =''
    displayWelcomeMessage(null)

    alert(`Du lieu ten se bi xoa`)

})

function displayWelcomeMessage(name){
    if (name) {
        welcomeMessage.textContent = `Xin chao ${name}. Chao mung ban den Website`
    } else {
        welcomeMessage.textContent = 'Chao mung ban den Website'

    }
}

document.addEventListener('DOMContentLoaded',()=>{
    const userSaved =  localStorage.getItem(STORAGE_KEY)
    displayWelcomeMessage(userSaved)
})

 const todos = JSON.parse(localStorage.getItem("todos")) || [];
todos.push("Học JS");
todos.push("Học React");
todos.push("Học TailwindCss");
localStorage.setItem("todos", JSON.stringify(todos));


