const todoInput = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const todoListUL = document.getElementById('todo-list');
const clearAllBtn = document.getElementById('clear-all-btn');
const STORAGE_KEY = 'miniTodoItems'; 

// Hàm lấy danh sách công việc từ localStorage
function getTodos() {
    // Đọc chuỗi JSON từ localStorage (mặc định là null nếu chưa có)
    const todosJSON = localStorage.getItem(STORAGE_KEY);
    
    // Chuyển chuỗi JSON thành Mảng JavaScript. 
    // Nếu là null (chưa có dữ liệu), trả về một mảng rỗng []
    return todosJSON ? JSON.parse(todosJSON) : [];
}

// Hàm lưu danh sách công việc vào localStorage
function saveTodos(todos) {
    // Chuyển Mảng JavaScript (dữ liệu phức tạp) thành chuỗi JSON
    const todosJSON = JSON.stringify(todos);
    
    // Lưu chuỗi JSON vào localStorage
    localStorage.setItem(STORAGE_KEY, todosJSON);
}

// Hàm render danh sách công việc ra giao diện (<ul>)
function renderTodos() {
    const todos = getTodos(); // Lấy dữ liệu từ storage
    todoListUL.innerHTML = ''; // Xóa nội dung hiện tại

    todos.forEach(todoText => {
        const listItem = document.createElement('li');
        listItem.textContent = todoText;
        todoListUL.appendChild(listItem);
    });
}

// 2. Xử lý sự kiện "Thêm"
function handleAddTodo() {
    const todoText = todoInput.value.trim();
    
    if (todoText === '') {
        alert('Vui lòng nhập công việc.');
        return;
    }

    const todos = getTodos();      // Lấy danh sách hiện tại
    todos.push(todoText);          // Thêm công việc mới vào mảng
    saveTodos(todos);              // Lưu mảng mới vào storage
    renderTodos();                 // Render lại giao diện

    todoInput.value = '';          // Xóa nội dung input
    todoInput.focus();
}

addBtn.addEventListener('click', handleAddTodo);

// Thêm sự kiện Enter để thêm nhanh
todoInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        handleAddTodo();
    }
});

// 3. Xử lý sự kiện "Clear all"
clearAllBtn.addEventListener('click', () => {
    if (confirm('Are you sure?')) {
        // Xóa toàn bộ dữ liệu của key 'miniTodoItems'
        localStorage.removeItem(STORAGE_KEY); 
        // Hoặc dùng localStorage.clear() để xóa HẾT MỌI THỨ trong storage
        // localStorage.clear(); 
        
        renderTodos(); // Render lại giao diện (sẽ là danh sách rỗng)
        alert('All tasks have been deleted');
    }
});


// 4. Load trang ban đầu
// Khi trang được tải, đọc dữ liệu từ storage và hiển thị
document.addEventListener('DOMContentLoaded', renderTodos);