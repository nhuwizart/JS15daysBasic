// --- 1. Truy cập các phần tử DOM cần thiết ---
const nameInput = document.getElementById('userNameInput');
const saveButton = document.getElementById('saveButton');
const clearButton = document.getElementById('clearButton'); // Thêm nút xóa
const welcomeMessage = document.getElementById('welcomeMessage');

const STORAGE_KEY = 'username'; 

saveButton.addEventListener('click', () => {
    const userName = nameInput.value.trim(); 
    
    if (userName) {
        localStorage.setItem(STORAGE_KEY, userName); 
        
        displayWelcomeMessage(userName);
        
        alert(`Đã lưu tên "${userName}" thành công!`);
    } else {
        alert('Vui lòng nhập tên của bạn.');
    }
});

clearButton.addEventListener('click', () => {
    localStorage.removeItem(STORAGE_KEY); 
    
    nameInput.value = '';
    displayWelcomeMessage(null);
    
    alert('Tên người dùng đã được xóa khỏi bộ nhớ.');
});

function displayWelcomeMessage(name) {
    if (name) {
        welcomeMessage.textContent = `👋 Xin chào, ${name}!`;
    } else {
        welcomeMessage.textContent = 'Chào mừng bạn đến với trang web!';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const savedName = localStorage.getItem(STORAGE_KEY);

    displayWelcomeMessage(savedName);
});