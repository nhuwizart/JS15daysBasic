<script>
const purchaseDropdownOptionClass1 = 'size-dropdown';
const purchaseDropdownOptionClass2 = 'color-dropdown';
let arrSizePurchase = [];
const purchasePriceClass = 'additionPrice-4pro';
const currentPrice = {};
const arrCart = [];
let elmCartItemTemplate = null, elmGiftItemTemplate = null;
let elmSummaryItemTemplate = null, elmSummaryGiftItemTemplate = null;
const couponCode = '';
let isCheckoutView = false, isApplyCoupon = false;
const loadProductMini = false;
let isPaypalPayment = false;
const ratioQty = 1;
const maxProduct = 4;
const giftPrice = 19.99; //($80)
let campaign2Info, campaign3Info, campaign4Info, mini2Info, mini3Info, mini4Info;
const 	XCID = '4405f5f3-eb46-46bd-8d96-f17f2c7d8c0d',
		webkey2Units = 'CF7D126D-471B-4091-A87F-B4606908B4E8',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/159
		webkey3Units = '6E8B6818-0371-4032-98DF-C35082DFAC47',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/160
		webkey4Units = 'E1F23D63-6B03-4FDF-A573-510A0FF0DB94',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/161
		shippingIds = {	webkey2Units: {1: 10044, 2: 10045},
					webkey3Units: {1: 10044, 2: 10045, 3: 10046},
					webkey4Units: {1: 10044, 2: 10045, 3: 10046, 4: 10047}};
					
const DATA_SETTING = {
	proImgClass: 'pro-img',
	giftImgClass: 'gift-img',
	opt1Class: 'color-option',
	opt1ShowClass: 'color-show',
	opt1ActiveClass: 'color-option.active',
	opt1LabelClass: 'color-text-choose',
	stickyBarOpt1Class: 'color-bottom',
	stickyBarOpt1DropdownClass: 'color-dropdown-bottom',
	opt1Value: 'White, Cream, Gray', // follow product name on CRM
	opt1Label: 'White, Cream, Gray',
	bracketsOpt1Begin: '(', // follow product name format
	bracketsOpt1End: ')', // follow product name format
	opt2Class: 'size-option',
	opt2ShowClass: 'size-show',
	opt2ActiveClass: 'size-option.active',
	opt2LabelClass: 'size-text-choose',
	stickyBarOpt2Class: 'size-bottom',
	stickyBarOpt2DropdownClass: 'size-dropdown-bottom',
	opt2Value: 'Twin, Full, Queen, King', // follow product name on CRM
	opt2Label: 'TWIN - 39" x 75" x 15", FULL - 54" x 75" x 15", QUEEN - 60" x 80" x 15", KING - 76" x 80" x 15"',
	bracketsOpt2Begin: '(', // follow product name format
	bracketsOpt2End: ')', // follow product name format
	mainQtyClass: 'main-screen',
	priceMain1UnitClass: 'discount-price-choose', // show on floating bar screen
	fullPriceMain1UnitClass: 'full-price-choose', // show on floating bar screen
	savePriceMain1UnitClass: 'saving-price-choose', // show on floating bar screen
	totalPriceMainScreenClass: 'total-main-price-choose', // show on main screen
	totalFullPriceMainScreenClass: 'total-main-fullprice-choose', // show on main screen
	totalSavePriceMainScreenClass: 'total-main-saveprice-choose', // show on main screen
	cartContentClass: 'cart-content', 
	cartProductClass: 'cart-pro',
	cartItemsClass: 'cart-items',
	cartItemClass: 'cart-item',
	cartOpt1Desc: 'color-desc',
	cartOpt2Desc: 'size-desc',
	cartImgClass: 'cart-image',
	cartItemQtyClass: 'numberTxt',
	cartSumItemClass: 'sum-item-count',
	cartSumPriceItemClass: 'sum-item-price',
	cartMessMaxQty: 'max-qty-msg',
	cartItemDiscountPriceClass: 'cart-discount-price-choose',
	cartItemFullPriceClass: 'cart-full-price-choose',
	cartItemSavePriceClass: 'cart-saving-price-choose',
	cartGiftGroupClass: 'gift-group',
	cartGiftItemClass: 'pro-gift',
	cartTotalFullPriceClass: 'total-fullprice-choose',
	cartTotalPriceClass: 'total-price-choose',
	cartTotalSavePriceClass: 'total-saveprice-choose',
	cartDiscountMessClass: 'discount',
	cartInsureshipContentClass: 'cart-insureship',
	btnProcessClass: 'proceed-btn',
	btnAddToCart: 'btn-addtocart',
	maxTotalQtyMessClass: 'max-total-qty-msg',
	summaryGroupClass: 'pro-info',
	summaryItemsProductClass: 'summary-items',
	summaryItemProductClass: 'sum-item',
	summaryGiftGroupClass: 'gift-group',
	summaryGiftItemClass: 'sum-gift',
	summarySubTotalClass: 'js-sum-sub-total',
	summaryShippingPriceClass: 'js-sum-shipping-price',
	summaryFullPriceClass: 'js-sum-full-price',
	summaryGrandSaveClass: 'js-grand-save',
	summaryTotalCountClass: 'sum-total-count',
	summaryTotalPriceChoose: 'sum-total-price-choose',
	summaryFullPriceChoose: 'sum-total-fullprice-choose',
	summaryItemQtyClass: 'sum-numberTxt',
	summarySafeTrakPriceClass: 'js-price-safetrak'
}

function updateDiscountPercent(){
	const elmBtnActiveCoupon = document.querySelectorAll(".popup-activate .js__btn-yes,.popup-activate .js__btn-close-and-active,.popup-activate .close-expopup-and-active");
  		
  	Array.prototype.slice.call(elmBtnActiveCoupon).forEach(item => {
    	item.addEventListener("click", function(){
          const elmPercentDefault = document.querySelectorAll(".js-list .js-list-item");
          
          Array.prototype.slice.call(elmPercentDefault).forEach(item => {
              const discount = item.querySelector(".discount-percent");
			  const discountCoupon = item.querySelector(".discount-percent-apply-coupon");
			  discount && discountCoupon && (discount.innerText = discountCoupon.innerText);
          })
		  
		  const currentPercent = document.querySelector('.list .list-item--checked .discount-percent');
		  const elmPerPriceChoose = document.querySelector(".percent-price-choose");
		  currentPercent && elmPerPriceChoose && (elmPerPriceChoose.innerText = currentPercent.innerText);
		  
          const elmMsgBeforeApply = document.querySelector(".msg-before-coupon-apply");
		  elmMsgBeforeApply &&  (elmMsgBeforeApply.style.display = "none");

		  const elmMsgAfterApply = document.querySelector(".msg-after-coupon-apply");
		  elmMsgAfterApply &&  (elmMsgAfterApply.style.display = "block");
          
          const elmAfterApplyChoose = document.querySelector(".coupon-apply-choose");
		  elmAfterApplyChoose &&  (elmAfterApplyChoose.style.display = "inline");
		  
		  setTimeout(() => {
			  const qty = parseInt(document.querySelector('.main-screen .numberTxt').value)
			  updateDiscountValue(qty);
		  }, 200)
      })
    })	 
    
} 

// Function for new feature: change PID when change size

function getAllCampaign() {
    const headers = {method: "GET",X_CID: XCID,"Content-Type": "application/json"};
    const webkeys = [webkey2Units, webkey3Units, webkey4Units];
	if (loadProductMini) {
		Promise.all(
			webkeys.map(key =>
				Promise.all([
					fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices`, { headers }).then(res => res.json()),
					fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices/miniupsells`, { headers }).then(res => res.json())
				])
			)
		)
		.then((results) => {
			// results: [ [prices2, upsells2], [prices3, upsells3], [prices4, upsells4] ]
			const [[prices2, upsells2], [prices3, upsells3], [prices4, upsells4]] = results;
			if(ratioQty){
			  prices2.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			  prices3.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			  prices4.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			}

			campaign2Info = prices2;
			mini2Info = upsells2;

			campaign3Info = prices3;
			mini3Info = upsells3;

			campaign4Info = prices4;
			mini4Info = upsells4;

			getPriceWithOptionSelect();
		})
		.catch(err => { console.log("get all campaign error:", err); });
	} else {
		Promise.all(
			webkeys.map(key =>
				fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices`, { headers }).then(res => res.json())
			)
		)
		.then(([info2, info3, info4]) => {
			if(ratioQty){
				info2.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
				})
				info3.prices.forEach(item => {
					item.quantity = item.quantity/ratioQty;
				})
				info4.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
				})
			}
			campaign2Info = info2;
			campaign3Info = info3;
			campaign4Info = info4;
			getPriceWithOptionSelect();
		}).catch(err => { console.log("get all campaign error: " + err); });
	}
}

function updateAllPrice(campaign, couponType, couponValue){
	if(!campaign) return;
	campaign.prices.forEach(pro => {
		if (couponType === 'percent'){
			const calculatePrice = (pro.productPrices.DiscountedPrice.Value * (1 - couponValue / 100)).toFixed(2);
			pro.productPrices.DiscountedPrice.Value = Number(calculatePrice);
			pro.productPrices.DiscountedPrice.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				pro.productPrices.DiscountedPrice.Value,
				pro.productPrices.DiscountedPrice.FormattedValue
			)
			
			if (pro.productPrices.UnitDiscountRate){
				const calculateUnitPrice = (pro.productPrices.UnitDiscountRate.Value * (1 - couponValue / 100)).toFixed(2)
				pro.productPrices.UnitDiscountRate.Value = Number(calculateUnitPrice)
				pro.productPrices.UnitDiscountRate.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				  pro.productPrices.UnitDiscountRate.Value,
				  pro.productPrices.UnitDiscountRate.FormattedValue
				)
			}
		} else {
			let newDiscountPrice = Number((elm.productPrices.DiscountedPrice.Value - couponValue).toFixed(2))
			let newUnitDiscountPrice = 0
			if (elm.productPrices.UnitDiscountRate) {
				newUnitDiscountPrice = Number((elm.productPrices.UnitDiscountRate.Value - couponValue / elm.quantity).toFixed(2))
			}
			if (isKasheeCoupon) {
				const itemDefault = priceDefaults.find((item) => item.productId === elm.productId)
				newDiscountPrice = Number((itemDefault.productPrices.DiscountedPrice.Value - couponValue).toFixed(2))
				if (elm.productPrices.UnitDiscountRate) {
				newUnitDiscountPrice = Number((itemDefault.productPrices.UnitDiscountRate.Value - couponValue / elm.quantity).toFixed(2))
				}
			}
			elm.productPrices.DiscountedPrice.Value = newDiscountPrice > 0 ? newDiscountPrice : 0
			elm.productPrices.DiscountedPrice.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				elm.productPrices.DiscountedPrice.Value,
				elm.productPrices.DiscountedPrice.FormattedValue
			)

			if (elm.productPrices.UnitDiscountRate) {
				elm.productPrices.UnitDiscountRate.Value = newUnitDiscountPrice > 0 ? newUnitDiscountPrice : 0
				elm.productPrices.UnitDiscountRate.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				elm.productPrices.UnitDiscountRate.Value,
				elm.productPrices.UnitDiscountRate.FormattedValue
				)
			}
		}
	})
}

function updateAllCampaignWithCoupon(){
	const elmExitPopup = document.querySelector("div[couponvalue]");
	if (!elmExitPopup || isApplyCoupon) return;
	
	const couponValue = elmExitPopup.getAttribute("couponvalue") ? parseInt(elmExitPopup.getAttribute("couponvalue")) : 0
	const couponType = elmExitPopup.getAttribute("coupontype") || 'percent';
	updateAllPrice(campaign2Info, couponType, couponValue);
	updateAllPrice(campaign3Info, couponType, couponValue);
	updateAllPrice(campaign4Info, couponType, couponValue);
	isApplyCoupon = true;
	setTimeout(() => {
	  const qty = parseInt(document.querySelector('.main-screen .numberTxt').value)
	  updateDiscountValue(qty);
	}, 200)
}

function validatePurchaseData(){
	const elmError = document.querySelector(".extra-item .error-size");
	const elmSizes = document.querySelectorAll(".extra-item .size-dropdown") || [];
	const elmColors = document.querySelectorAll(".extra-item select.color-dropdown") || [];
	let isValidateSize = true;
	for(let i=0; i< elmSizes.length; i++){
		const itemSize = elmSizes[i];
		const itemColor = elmColors[i];
		if(!itemSize.value || !itemColor.value){
			isValidateSize = false;
			elmError && elmError.classList.remove("js-hidden");
			return;
		}
		
		const isExistIndex = arrSizePurchase.findIndex(obj => {
			return obj.size === itemSize.value && obj.color === itemColor.value;
		})
		
		if(isExistIndex === -1){
			const obj = {
				size: itemSize.value,
				color: itemColor.value,
				qty: 1
			}
			arrSizePurchase.push(obj);
		} else {
			arrSize[isExistIndex].qty += 1;
		}
	}
	Array.prototype.slice.call(elmSizes).forEach(item => {
		if(!item.value) {
			isValidateSize = false;
			elmError && elmError.classList.remove("js-hidden");
			return;
		}
		
		const isExistIndex = arrSizePurchase.findIndex(obj => {
			return obj.size === item.value;
		})
		
		if(isExistIndex === -1){
			const obj = {
				size: item.value,
				qty: 1
			}
			arrSizePurchase.push(obj);
		} else {
			arrSizePurchase[isExistIndex].qty += 1;
		}
	})
	
	return isValidateSize;
}

function getCurrentMainProduct(qty){
	let pro = null;
	switch (qty){
		case 1:
			pro = JSON.parse(window.localStorage.getItem('products'));
			break;
		case 2:
			pro = campaign2Info ? campaign2Info.prices : null;
			break;
		case 3:
			pro = campaign3Info ? campaign3Info.prices : null;
			break;
		case 4:
			pro = campaign4Info ? campaign4Info.prices : null;
			break;
		default:
			break;
	}
	
	return pro;
}

function getCurrentMiniProduct(qty){
	let pro = null;
	switch (qty){
		case 1:
			pro = window.miniUpsellsWidget || null;
			break;
		case 2:
			pro = mini2Info || null;
			break;
		case 3:
			pro = mini3Info || null;
			break;
		case 4:
			pro = mini4Info || null;
			break;
		default:
			break;
	}
	
	return pro;
}

// get product with option
function getProduct(obj, isPurchase = false, isMainScreen = false ){
	if(!window.localStorage.getItem('products')) return;
	
	let totalQty = 0;
	if(isMainScreen){
		totalQty = parseInt(document.querySelector('.main-screen input.numberTxt').value)
	} else {
		arrCart.forEach(item => {
			totalQty += item.qty;
		})
	}
	
	if(totalQty === 0) totalQty = obj.qty;
	const products = getCurrentMainProduct(totalQty);
	const pro = products.find(pro => {
		return 	pro.quantity === obj.qty && 
				pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${obj.opt1.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1 && 
				pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt2Begin}${obj.opt2.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt2End}`) > -1;
	})
	if(pro){
		obj.product = pro;
		return pro;
	}
	
	return null;
}

// get gift with option

function getGiftProductBeforeSubmit(){
	if(!window.miniUpsellsWidget) return;
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	arrCart.forEach(obj => {
		const pro = window.miniUpsellsWidget.find(pro => {
			return 	pro.quantity === obj.qty && 
					pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${obj.opt1.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1 && 
					pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt2Begin}${obj.opt2.toLocaleLowerCase() === 'xs' ? 's/m' : obj.opt2.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt2End}`) > -1;
		})
		
		if(pro){
			mini.push({productId: pro.productId, shippingMethodId: pro.shippings[0].shippingMethodId})
		}
	})
	
	window.ctrwowCheckout.checkoutData.setMiniUpsell(mini);
}

function getShipping(qty, obj, isMain){
	switch(qty){
		case 2:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey2Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey2Units[2];
			}
			window.__ctrPageConfiguration.webKey = webkey2Units;
            
			break;
		case 3:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[2];
			} else if(obj.qty === 3){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[3];
			}
			window.__ctrPageConfiguration.webKey = webkey3Units;
            break;
		case 4:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[2];
			} else if(obj.qty === 3){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[3];
			} else if(obj.qty === 4){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[4];
			}
			window.__ctrPageConfiguration.webKey = webkey4Units;
            break;
	}
	
	//set location to local storage with new webkey
	if(isMain){
		let campProducts = window.localStorage.getItem('campproducts');
		campProducts = campProducts ? JSON.parse(campProducts) : [];
		const isExistCamps = campProducts.camps.filter(camp => {
			return camp[window.__ctrPageConfiguration.webKey];
		});
		if(!isExistCamps || isExistCamps.length === 0){
			const obj = {};
			obj[window.__ctrPageConfiguration.webKey] = window.__productListData.data.productList;
			campProducts.camps.push(obj);
			window.localStorage.setItem('campproducts', JSON.stringify(campProducts));
		}
	}
	return obj.product.shippings;
}

function bindData4Checkout(){
	arrCart.sort((obj1, obj2) => {
		return obj2.qty - obj1.qty;
	})
	
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	const currentProduct = window.ctrwowCheckout.checkoutData.getProduct();
	currentProduct.productId = arrCart[0].product.productId;
	
	window.multiMainProducts = null;
	let shippingIndex = window.shippingIndex || 0;
	if(arrCart.length >= 1){
		//currentProduct.shippings = arrCart[0].product.shippings;
		currentProduct.shippings = getShipping(totalQty, arrCart[0], true);
		const multiMainProducts = [];
		multiMainProducts.push({
			productId: currentProduct.productId,
			shippingMethodId: currentProduct.shippings && currentProduct.shippings.length > shippingIndex ? currentProduct.shippings[shippingIndex].shippingMethodId : null
		});
		
		localStorage.removeItem("extendedtext");
		
		for(let i = 1; i < arrCart.length; i++){
			const obj = arrCart[i].product;
			//const shippings = obj.shippings;
			const shippings = getShipping(totalQty, arrCart[i], true);
			const pro = {
				productId: obj.productId,
				shippingMethodId: shippings && shippings.length > 0 ? shippings[0].shippingMethodId : null
			}
			multiMainProducts.push(pro);
		}
		
		window.multiMainProducts = multiMainProducts;
	}
}

function bindPurchaseDataWithSize(){
	let qty = 0;
	arrSizePurchase.forEach(obj => {
		getProduct(obj, true);
		qty+=obj.qty;
	})
	arrSizePurchase.sort((obj1, obj2) => {
		return obj2.qty - obj1.qty;
	})
	
	const currentProduct = window.miniUpsells[0];
	currentProduct.productId = arrSizePurchase[0].product.productId;
	
	window.multipleMiniUpsells = [];
	
	for(let i = 1; i < arrSizePurchase.length; i++){
		const obj = arrSizePurchase[i].product;
		const pro = {
			productId: obj.productId,
			shippingMethodId: shippings && shippings.length > 0 ? shippings[0].shippingMethodId : null,
			price: obj.productPrices.DiscountedPrice.Value,
			type: 'mini',
			addToSummary: false
		}
		window.multipleMiniUpsells.push(pro);
	}
}

function triggerPaymentButton(){
	const elmBtns = document.querySelectorAll(".paypal-placeholder, button[name='checkoutWithCreditCardV1']");
	Array.prototype.slice.call(elmBtns).forEach(btn => {
		btn.addEventListener("click", function(e){
			bindData4Checkout()
		})
	})

	const elmRealPP = document.querySelectorAll("button.checkoutWithPaypal");
	Array.prototype.slice.call(elmRealPP).forEach(btn => {
		btn.addEventListener("click", function(e){
			//getGiftProductBeforeSubmit();
			bindData4Checkout();
		})
	})
	
	const elmAddPurchase = document.querySelectorAll(".popup_widget_content .btn-add-purchase");
	Array.prototype.slice.call(elmAddPurchase).forEach(btn => {
		btn.addEventListener("click", function(e){
			
			if(!validatePurchaseData()){
				e.preventDefault();
				e.stopImmediatePropagation();
				e.stopPropagation();
				return;
			}
			
			bindPurchaseDataWithSize();
			const elmPurchase = document.querySelector(".popup_widget_content .btn-add");
			elmPurchase && elmPurchase.click();
		})
	})
}
triggerPaymentButton();

window.ctrwowUtils.events.on("ctr_form_checkoutWithCreditCardV1", (data) => {
	if(data.customer){
		//getGiftProductBeforeSubmit();
	}
})

// reset size when load page
function resetSize(){
	const elmSizes = document.querySelectorAll(".size .size-option");
	Array.prototype.slice.call(elmSizes).forEach(item => {
		item.value = "Twin";
		
	})
	
	/*const elmColors = document.querySelectorAll(".color-dropdown");
	Array.prototype.slice.call(elmColors).forEach(item => {
		item.value = "Black";
		
	})*/
}


function triggerFirstChangeOpt1(){
	const elmOpt1s = document.querySelectorAll(`.${DATA_SETTING.opt1Class}`);
	const elmOpt1Label = document.querySelector(`.${DATA_SETTING.opt1LabelClass}`);
	const elmOpt1Bottom = document.querySelectorAll(`.sticky-bar .${DATA_SETTING.stickyBarOpt1Class}`);
	const elmOpt1DropdownBottom = document.querySelector(`.sticky-bar .${DATA_SETTING.stickyBarOpt1DropdownClass}`);
	const elmOpt1Sliders = document.querySelectorAll(`.widget-slider.${DATA_SETTING.opt1ShowClass}`);
	elmOpt1s.forEach(item => {
		item.addEventListener('click', (e) => {
			elmOpt1s.forEach(el => {
				el.classList.remove('active');
			})
			e.currentTarget.classList.add('active');
			elmOpt1Label.innerText = item.dataset.label;
			
			getPriceWithOptionSelect();
			
			elmOpt1Bottom.forEach(e => {
				e.classList.add('js-hidden');
			})
			
			const currentImg = document.querySelector(`.sticky-bar img.${item.dataset.value.toLocaleLowerCase()}-show`);
			currentImg && currentImg.classList.remove('js-hidden');
			
			elmOpt1DropdownBottom && (elmOpt1DropdownBottom.value = item.dataset.value);
			
			/*// show/hide slider
			elmOpt1Sliders.forEach(s => {
				s.classList.add('js-hidden');
			})
			
			const currentSlider = document.querySelector(`.widget-slider.${item.dataset.value.toLocaleLowerCase()}-show`);
			currentSlider && currentSlider.classList.remove('js-hidden');
			const mainSlider = currentSlider.querySelector('.main-slider');
			mainSlider && mainSlider?.slick?.setPosition();*/
			
			//scorll to slider
			const currentSlider = document.querySelector(`.slick-track .slide-${item.dataset.value.toLocaleLowerCase()}`);
			currentSlider && currentSlider.click();
		})
	})
	
	elmOpt1DropdownBottom && elmOpt1DropdownBottom.addEventListener('change', (e) => {
		const value = e.currentTarget.value;
		const elmOption1 = document.querySelector(`.${DATA_SETTING.opt1Class}[data-value="${value}"]`);
		elmOption1 && elmOption1.click();
	})
	
}
triggerFirstChangeOpt1();

function triggerFirstChangeOpt2(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size select');
	const elmOpt2DropdownBottom = document.querySelector(`.sticky-bar .${DATA_SETTING.stickyBarOpt2DropdownClass}`);
        elmSizeOptions.forEach((elm) => {

            elm.addEventListener('change', (e)=>{
                const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
                updateLayoutWithSelectOption(qty);
                if (e.currentTarget.closest('.size-1')){
                    elmOpt2DropdownBottom.value = e.currentTarget.value;

                }

            })
        })
        elmOpt2DropdownBottom && elmOpt2DropdownBottom.addEventListener('change', (e) => {
            const value = e.currentTarget.value;
            const elmOption2 = document.querySelector('.option-group .size-box .size-1 select');
            if (elmOption2){
                elmOption2.value = value;
                elmOption2.dispatchEvent(new Event('change'))
            }
        }
        )

}
triggerFirstChangeOpt2();

function triggerExitPopup(){
	const elmBtns = document.querySelectorAll(".close-expopup-and-active, .popup-activate__btn-yes");
	elmBtns.forEach(elm => {
		elm.addEventListener("click", () => {
			getPriceWithOptionSelect();
		})
	})
}

// trigger buttin add to cart
function triggerAddToCart(){
	const elmBtnAddToCarts = document.querySelectorAll(`.${DATA_SETTING.btnAddToCart}`);
	elmBtnAddToCarts.forEach(btn => {
		btn.addEventListener('click', (e) => {
			const elmOpt1 = document.querySelector(`.${DATA_SETTING.opt1ActiveClass}`);
			const elmOpt1Img = elmOpt1.querySelector(`img.${DATA_SETTING.proImgClass}`);
			const elmOpt1Gift = elmOpt1.querySelector(`img.${DATA_SETTING.giftImgClass}`);
			// const elmOpt2 = document.querySelector(`.${DATA_SETTING.opt2ActiveClass}`);
			const opt1Value = elmOpt1?.dataset.value;
			// const opt2Value = elmOpt2?.dataset.value;
			const lblOpt1 = elmOpt1?.dataset.label;
			// const lblOpt2 = elmOpt2?.dataset.label;
			
			if(!opt1Value) return;
			const elmOpt2s =  document.querySelectorAll('.option-group .size-box .size:not(.js-hidden)')

            elmOpt2s.forEach(elmOpt2 => {
                const opt2Value = elmOpt2.querySelector('select').value;
                const lblOpt2 = opt2Value

                // const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
                const qty = 1;
                const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: qty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmOpt1Img?.src};
                const product = getProduct(productInfo, false, true);
                let countPro = 0;
			arrCart.forEach(info => {
				countPro += info.qty;
			})
                if(countPro < maxProduct){
                    const isExistsPro = arrCart.find(item => {
                        return item.opt1 === opt1Value && item.opt2 === opt2Value;
                    })
                    
                    if(!isExistsPro){
                        let newQty = qty > (maxProduct - countPro) ? maxProduct - countPro : qty
                        const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: newQty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmOpt1Img?.src, giftImg: elmOpt1Gift?.src};
                        const product = getProduct(productInfo, false);
                        product && arrCart.push(productInfo);
                    }else{
                        isExistsPro.qty += qty;
                        if(isExistsPro.qty > maxProduct) isExistsPro.qty = maxProduct;
                        getProduct(isExistsPro, false);
                    }
                } 

            })
			
			
			
			
			
			
			replaceCartNumberProduct();
			updateCartInfo();
			
			//reset qty
            const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
			elmQty && (elmQty.value = 1);
			resetSize();
			updateSizeOption();
			updateLayoutWithSelectOption(1);
			updateDiscountValue(1);
		})
	})
}

// bind price each item in mini cart
function bindPriceToLayout(product, groupItem, clsPrice, clsFullPrice, clsSave, isShowUnit = false){
	const elmPrice = groupItem.querySelectorAll(`.${clsPrice}`);
	const elmFullPrice = groupItem.querySelectorAll(`.${clsFullPrice}`);
	const elmSavePrice = groupItem.querySelectorAll(`.${clsSave}`);
	let price = null;
	let fullPrice = null;
	let priceFormat = null;
	let fullPriceFormat = null
	
	if(isShowUnit){
		price = product.productPrices?.UnitDiscountRate?.Value;
		fullPrice = product.productPrices?.UnitFullRetailPrice?.Value;
		priceFormat = product.productPrices?.UnitDiscountRate?.FormattedValue;
		fullPriceFormat = product.productPrices?.UnitFullRetailPrice?.FormattedValue
	}
	
	if(!price) price = product.productPrices.DiscountedPrice.Value;
	if(!fullPrice) fullPrice = product.productPrices.FullRetailPrice.Value;
	if(!priceFormat) priceFormat = product.productPrices.DiscountedPrice.FormattedValue;
	if(!fullPriceFormat) fullPriceFormat = product.productPrices.FullRetailPrice.FormattedValue;
	
	elmPrice.forEach(item => {
		item.innerText = priceFormat;
		item.classList.remove('loading');
	})
	
	elmSavePrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, product.productPrices.DiscountedPrice.FormattedValue);
		item.classList.remove('loading');
	})
	
	elmFullPrice.forEach(item => {
		item.innerText = fullPriceFormat;
		item.classList.remove('loading');
	})
}

// update price and get product info
function getFirstProductPrice(color, size, lblSize, img){
	const productInfo = {color: color, size: size, qty: 1, lblSize: lblSize, img: img};
	const product = getProduct(productInfo, false);
	if(product){
		const groupItem = document.querySelector('body');
		bindPriceToLayout(product, groupItem, 'discount-price-choose', 'full-price-choose', 'saving-price-choose', true);
	}
}

function getPriceWithOptionSelect(){
	const arrP = [];
    let firstPro = null;

	const elmOpt1 = document.querySelector(`.${DATA_SETTING.opt1ActiveClass}`);
	const elmImg = document.querySelector(`.${DATA_SETTING.opt1ActiveClass} img`);
	// const elmOpt2 = document.querySelector(`.${DATA_SETTING.opt2ActiveClass}`);
	const opt1Value = elmOpt1?.dataset.value;
	// const opt2Value = elmOpt2?.dataset.value;
	const lblOpt1 = elmOpt1?.dataset.label;
	// const lblOpt2 = elmOpt2?.dataset.label;
	
	if(!opt1Value) return
	const elmOpt2s =  document.querySelectorAll('.option-group .size-box .size:not(.js-hidden)')

    elmOpt2s.forEach(elmOpt2 => {
        const opt2Value = elmOpt2.querySelector('select').value;
        const lblOpt2 = opt2Value

        // const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
        const qty = 1;
        const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: qty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmImg?.src};
		
		let isExistsPro = arrP.find(p => {
			return p.opt1 === opt1Value && p.opt2 === opt2Value;
		})
		
		if(isExistsPro){
			isExistsPro.qty += qty;
			getProduct(isExistsPro, false, true);
		}else {
			const product = getProduct(productInfo, false, true);
			if(product){
				if (firstPro === null) {
					firstPro= product;

				}
				arrP.push(productInfo);
			}
		}
    })
	
	let totalFullMainPrice = 0, totalMainPrice = 0;
	arrP.forEach(p => {
		totalFullMainPrice += p.product.productPrices.FullRetailPrice.Value;
		totalMainPrice += p.product.productPrices.DiscountedPrice.Value;
	})
	
	const elmTotalMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalPriceMainScreenClass}`);
	elmTotalMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmTotalFullMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalFullPriceMainScreenClass}`);
	elmTotalFullMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalFullMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmSaveMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalSavePriceMainScreenClass}`);
	elmSaveMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalFullMainPrice - totalMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	
	//show price for floating bar
	// const product1UnitInfo = {opt1: opt1Value, opt2: opt2Value, qty: 1, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmImg?.src};
	const product1Unit = firstPro //getProduct(product1UnitInfo, false, true);
	
	if(!product1Unit) return
	
	
	let fullMainPrice = 0, mainPrice = 0;
	fullMainPrice += product1Unit.productPrices.FullRetailPrice.Value;
	mainPrice += product1Unit.productPrices.DiscountedPrice.Value;
	
	const elmMainPrice = document.querySelectorAll(`.${DATA_SETTING.priceMain1UnitClass}`);
	elmMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(mainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmFullMainPrice = document.querySelectorAll(`.${DATA_SETTING.fullPriceMain1UnitClass}`);
	elmFullMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmSavePrice = document.querySelectorAll(`.${DATA_SETTING.savePriceMain1UnitClass}`);
	elmSavePrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullMainPrice - mainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
}

function updateLayoutWithSelectOption(qty){
	getPriceWithOptionSelect();
	updateCartInfo();
}

function updateSizeOption(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size');
    const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
    elmSizeOptions.forEach((elm,index) => {
        if (index<qty){
            elm.classList.remove('js-hidden')

        } else {
            elm.classList.add('js-hidden')
        }
    })
    
}

function triggerSizeChange(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size select');
    elmSizeOptions.forEach((elm) => {
        elm.addEventListener('change', ()=>{
            const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
            updateLayoutWithSelectOption(qty);
            

        })
    })
    elmOpt2DropdownBottom && elmOpt2DropdownBottom.addEventListener('change', (e) => {
        const value = e.currentTarget.value;
        const elmOption2 = document.querySelector(`.${DATA_SETTING.opt2Class}[data-value="${value}"]`);
        elmOption2 && elmOption2.click();
    }
    )

}

function updateDiscountValue(qty){
	const elmDiscountValue = document.querySelectorAll('.msg-before-coupon-apply .hb-value, .msg-after-coupon-apply .hb-value');
	let value = '50%';
	switch(qty){
		case 1:
			value = '50%';
			
			break;
		case 2:
			value = '50%';
			break;
		case 3:
			value = '60%';
			break;
		case 4:
			value = '62%';
			break;
	}
	
	elmDiscountValue.forEach(elm => {
		elm.innerText = value;
	})
}

function triggerAddMoreItemOnMain(){
	// add more  button
	const btnPlus = document.querySelector('.return-here span.plus');
	btnPlus && btnPlus.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		
		const elmParent = e.currentTarget.closest('.custom-number');
		if (!elmParent) return;
		
		
		
		const elmQty = elmParent.querySelector('input.numberTxt');
		let qty = elmQty ? parseInt(elmQty.value) : null;
		
		if(!qty || qty === maxProduct) return;
		qty += 1;
		
		
		if(qty >= maxProduct) {
			qty = maxProduct;
		}
		
		elmQty.value = qty;
        updateSizeOption();

		updateLayoutWithSelectOption(qty);
		updateDiscountValue(qty);
	})
	
	const btnMinus = document.querySelector('.return-here span.minus');
	btnMinus && btnMinus.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		const elmParent = e.currentTarget.closest('.custom-number');
		if (!elmParent) return;
		const elmQty = elmParent.querySelector('input.numberTxt');
		let qty = elmQty ? parseInt(elmQty.value) : null;
		
		if(!qty || qty === 1) return;
		qty -= 1;
		elmQty.value = qty;
		updateSizeOption();

		updateLayoutWithSelectOption(qty);
		updateDiscountValue(qty);
	})
	
}
triggerAddMoreItemOnMain();

// Trigger click detete product and add more item in mini cart
function triggerActionInCart(elmCartItemsParent){
	// delete button
	const btnDeleteds = elmCartItemsParent.querySelectorAll('.delete-btn');
	btnDeleteds.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if(!elmParent) return;
			const index = parseInt(elmParent.dataset.index);
			
			if(typeof index !== "undefined"){
				arrCart.splice(index, 1);
				replaceCartNumberProduct();
				updateCartInfo();
			}
		})
	})
	
	// add more  button
	const btnPlus = elmCartItemsParent.querySelectorAll('span.plus');
	btnPlus.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if (!elmParent) return;
			
			const elmQty = elmParent.querySelector('input.numberTxt');
			let qty = elmQty ? parseInt(elmQty.value) : null;
			const index = parseInt(elmParent.dataset.index);
			
			let countPro = 0;
			arrCart.forEach(info => {
				countPro += info.qty;
			})
			
			if(!qty || qty === maxProduct || typeof index === "undefined" || countPro >= maxProduct) return;
			qty += 1;
			const productInfo = arrCart[index];
			
			if(!productInfo) return;
			productInfo.qty = qty;
			getProduct(productInfo, false);
			replaceCartNumberProduct();
			updateCartInfo();
		})
	})
	
	const btnMinus = elmCartItemsParent.querySelectorAll('span.minus');
	btnMinus.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if (!elmParent) return;
			
			const elmQty = elmParent.querySelector('input.numberTxt');
			let qty = elmQty ? parseInt(elmQty.value) : null;
			const index = parseInt(elmParent.dataset.index);
			
			if(!qty || qty === 1 || typeof index === "undefined") return;
			qty -= 1;
			const productInfo = arrCart[index];
			
			if(!productInfo) return;
			productInfo.qty = qty;
			getProduct(productInfo, false);
			replaceCartNumberProduct();
			updateCartInfo();
		})
	})
}

// update each item in mini cart
function bindData2CartItem(info, cartItem, itemIndex){
	if(!info || !info.product) return;
	cartItem.dataset.index = itemIndex;
	const elmSources = cartItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} picture source`);
	elmSources.forEach(source => {
		source.remove();
	});
	
	const img = cartItem.querySelector(`.${DATA_SETTING.cartImgClass} img`);
	if(img){
		img.removeAttribute('data-srcsets');
		img.removeAttribute('data-lazy-srcsets');
		img.setAttribute('src', info?.img);
	}
	
	const elmOpt1Desc = cartItem.querySelector(`.${DATA_SETTING.cartOpt1Desc}`);
	elmOpt1Desc && (elmOpt1Desc.innerText = info?.lblOpt1);
	
	const elmOpt2Desc = cartItem.querySelector(`.${DATA_SETTING.cartOpt2Desc}`);
	elmOpt2Desc && (elmOpt2Desc.innerText = info?.lblOpt2);
	
	const elmQty = cartItem.querySelector(`.${DATA_SETTING.cartItemQtyClass}`);
	elmQty && (elmQty.value = info?.qty);
	
	const elmSumQty = cartItem.querySelector(`.${DATA_SETTING.cartSumItemClass}`);
	elmSumQty && (elmSumQty.innerText = info?.qty);
	
	const elmSumPrice = cartItem.querySelector(`.${DATA_SETTING.cartSumPriceItemClass}`);
	elmSumPrice && (elmSumPrice.innerText = info.product.productPrices.DiscountedPrice.FormattedValue);
	
	const elmMaxQtyMsg = cartItem.querySelector(`.${DATA_SETTING.cartMessMaxQty}`);
	elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
	if (info && info.qty === 5){
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.remove('js-hidden'));
	}
	
	//bind price each item in mini cart
	bindPriceToLayout(info.product, cartItem , DATA_SETTING.cartItemDiscountPriceClass, DATA_SETTING.cartItemFullPriceClass, DATA_SETTING.cartItemSavePriceClass, false);
}

function bindData2CartGift(info, cartGiftItem){
	if(!info || !info.product) return;
	const elmSources = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} picture source`);
	elmSources.forEach(source => {
		source.remove();
	});
	
	const isExistImgs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt1ShowClass}.${info?.lblOpt1?.toLocaleLowerCase().replace(/ /g,'-')}`) || cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartGiftGroupClass} .${DATA_SETTING.opt2ShowClass}.${info?.lblOpt2?.toLocaleLowerCase().replace(/ /g,'-')}`);
	if (isExistImgs.length > 0){
		const allImgs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt1ShowClass}`) || cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt2ShowClass}`);
		allImgs.forEach(img => {
			img.classList.add('js-hidden');
		})
		isExistImgs.forEach(img => {
			img.classList.remove('js-hidden');
		}) 
	}else{
		const img = cartGiftItem.querySelector(`.${DATA_SETTING.cartImgClass} img`);
		if(img){
			img.removeAttribute('data-srcsets');
			img.removeAttribute('data-lazy-srcsets');
			img.setAttribute('src', info?.giftImg);
		}
	}
	
	
	const elmOpt1Descs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartOpt1Desc}`);
	elmOpt1Descs.forEach(elmOpt1Desc => {
		elmOpt1Desc.innerText = info?.lblOpt1;
	})
	
	const elmOpt2Descs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartOpt2Desc}`);
	elmOpt2Descs.forEach(elmOpt2Desc => {
		elmOpt2Desc.innerText = info?.lblOpt2
	})
	
	const elmQtys = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartItemQtyClass}`);
	elmQtys.forEach(elmQty => {
		elmQty.value = info?.qty;
	})
	
	const elmSumQtys = cartGiftItem.querySelectorAll(`.${DATA_SETTING.summaryItemQtyClass}`);
	elmSumQtys.forEach(elmSumQty => {
		elmSumQty.innerText = info?.qty;
	})
	
	const elmFullPrice = cartGiftItem.querySelectorAll(`.addon-fullprice`);
	const elmPrice = cartGiftItem.querySelectorAll(`.addon-price`);
	elmFullPrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(giftPrice * info?.qty, info.product.productPrices.DiscountedPrice.FormattedValue);
	})
	
	elmPrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(0, info.product.productPrices.DiscountedPrice.FormattedValue);
	})
	
}

function updateTotalPrice4MiniCart(price, fullPrice){
	const elmCartContent = document.querySelector(`.${DATA_SETTING.cartContentClass}`);
	const elmTotalFullPrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalFullPriceClass}`);
	const elmTotalPrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalPriceClass}`);
	const elmTotalSavePrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalSavePriceClass}`);
	
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	mini.forEach(item => {
		price += item.productPrices.DiscountedPrice.Value;
		fullPrice += item.productPrices.FullRetailPrice.Value;
	})
	
	elmTotalFullPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
	elmTotalPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
	elmTotalSavePrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
}

//show discount percent
function displayDiscountPercent(){
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	if(totalQty === 0) totalQty = 1;
	
	const elmDiscount = document.querySelectorAll(`.${DATA_SETTING.cartContentClass} .${DATA_SETTING.cartDiscountMessClass}`);
	elmDiscount.forEach((item, index) => {
		item.classList.add('js-hidden');
		if(index + 1 === totalQty){
			item.classList.remove('js-hidden');
		}
		
	});
}

function reUpdateProFollowCampaign(){
	let totalQty = 0;
	arrCart.forEach(info => {
		getProduct(info, false);
	})
}

// update cart icon number and mini card info
function updateCartInfo(){
	const elmCartContent = document.querySelector(`.${DATA_SETTING.cartContentClass}`);
	const elmCartPro = elmCartContent.querySelector(`.${DATA_SETTING.cartProductClass}`);
	const elmCartItemsParent = elmCartPro.querySelector(`.${DATA_SETTING.cartItemsClass}`);
	
	const elmBtnProceed = elmCartContent.querySelector(`.${DATA_SETTING.btnProcessClass}`);
	!elmCartItemTemplate && (elmCartItemTemplate = elmCartItemsParent.querySelector(`.${DATA_SETTING.cartItemClass}`).cloneNode(true));
	
	const elmCartGiftParent = elmCartContent.querySelector(`.${DATA_SETTING.cartGiftGroupClass}`);
	//!elmGiftItemTemplate && (elmGiftItemTemplate = elmCartGiftParent.querySelector(`.${DATA_SETTING.cartGiftItemClass}`).cloneNode(true));
	!elmGiftItemTemplate && (elmGiftItemTemplate = elmCartGiftParent.cloneNode(true));
	
	const elmMaxQtyMsg = document.querySelector(`.${DATA_SETTING.cartMessMaxQty}`);
	
	//show discount message
	displayDiscountPercent();
	
	//update cart count
	replaceCartNumberProduct();
	
	if(arrCart.length === 0){
		elmCartPro && elmCartPro.classList.add('js-hidden');
		elmCartGiftParent && elmCartGiftParent.classList.add('js-hidden');
		elmBtnProceed && elmBtnProceed.classList.add('disableCls');
		let price = 0, fullPrice = 0;
		//update total price
		updateTotalPrice4MiniCart(price,fullPrice);
		
		//hide message
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
	} else {
		//update shipping price follow campaign
		reUpdateProFollowCampaign();
		
		//update insurance follow qty
        reCalInsurancePrice();
		
		elmCartPro && elmCartPro.classList.remove('js-hidden');
		elmCartGiftParent && elmCartGiftParent.classList.remove('js-hidden');
		elmBtnProceed && elmBtnProceed.classList.remove('disableCls');
		let price = 0, fullPrice = 0;
		
		elmCartItemsParent.innerHTML = '';
		const firstTemp = elmCartItemTemplate.cloneNode(true);
		bindData2CartItem(arrCart[0], firstTemp, 0);
		elmCartItemsParent.appendChild(firstTemp);
		price += arrCart[0].product.productPrices.DiscountedPrice.Value;
		fullPrice += arrCart[0].product.productPrices.FullRetailPrice.Value;
		
		//for gift
		elmCartGiftParent.innerHTML = '';
		const firstGiftTemp = elmGiftItemTemplate.cloneNode(true);
		bindData2CartGift(arrCart[0], firstGiftTemp);
		elmCartGiftParent.appendChild(firstGiftTemp);
		fullPrice += (giftPrice * arrCart[0].qty)*2;
		
		for(let i= 1; i < arrCart.length; i++){
			const info = arrCart[i];
			const temp = elmCartItemTemplate.cloneNode(true);
			bindData2CartItem(info, temp, i);
			elmCartItemsParent.appendChild(temp);
			price += info.product.productPrices.DiscountedPrice.Value;
			fullPrice += info.product.productPrices.FullRetailPrice.Value;
			
			//for gift
			const giftTemp = elmGiftItemTemplate.cloneNode(true);
			bindData2CartGift(info, giftTemp);
			elmCartGiftParent.appendChild(giftTemp);
			fullPrice += (giftPrice * info.qty)*2;
		}
		
		//update total price
		updateTotalPrice4MiniCart(price,fullPrice);
	
		// Trigger click detete product and add more item in mini cart
		triggerActionInCart(elmCartItemsParent);
		
		//detect show message
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
		let countQty = 0;
		arrCart.forEach(p => {
			countQty += p.qty;
		})
		if (countQty >= 4){
			elmMaxQtyMsg && (elmMaxQtyMsg.classList.remove('js-hidden'));
		}
	}
}

// reUpdate Insurance Info
function reCalInsurancePrice() {
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	if(totalQty === 0) totalQty = 1;
	
	const pro = window.__productListData.data.productList.prices.find(p => {
		return p.quantity === totalQty
	})
	
    const currentPid = pro.productId;
    const insureshipPidListStr = document.querySelector(`.${DATA_SETTING.cartInsureshipContentClass}`);
    const insureshipPidSList = insureshipPidListStr ? JSON.parse(insureshipPidListStr.getAttribute('pid')) : null;
    if (!insureshipPidSList)
        return;

    const currentInsureshipPid = insureshipPidSList[currentPid];
    let insureshipPids = Object.values(insureshipPidSList);
    //convert pid to String
    insureshipPids = insureshipPids.map(String);

    let mini = window.ctrwowCheckout.checkoutData.getMiniUpsell();

    //remove insureship
    mini = mini.filter(item => {
        return insureshipPids.indexOf(item.productId.toString()) === -1;
    }
    )

    if (!currentInsureshipPid)
        return;
    const miniProduct = window.miniUpsellsWidget || window.miniUpsells;
    const currentInsureship = miniProduct.find(item => {
        return item.productId.toString() === currentInsureshipPid.toString();
    }
    )

    if (currentInsureship) {
        const elmPrices = insureshipPidListStr.querySelectorAll('.addon-price');
        const isChecked = insureshipPidListStr.querySelector('input');
        if (isChecked && isChecked.checked) {
            mini.push({
                productId: currentInsureship.productId,
                shippingMethodId: currentInsureship.shippings.length > 0 ? currentInsureship.shippings[0].shippingMethodId : null,
                productName: currentInsureship.productName,
                price: currentInsureship.price,
                productPrices: currentInsureship.productPrices,
                shippings: currentInsureship.shippings
            });
        }
        elmPrices.forEach(elmPrice => {
            elmPrice.innerText = currentInsureship.productPrices.DiscountedPrice.FormattedValue;
        })
		
		const elmSafeTrakPrice = document.querySelectorAll(`.${DATA_SETTING.summarySafeTrakPriceClass}`);
		elmSafeTrakPrice.forEach(elm => {
			elm.innerText = currentInsureship.productPrices.DiscountedPrice.FormattedValue;
		})

    }

    window.ctrwowCheckout.checkoutData.setMiniUpsell(mini);
}

// update product and price to checkout screen
function bindData2OrderSummary(){
	if (arrCart.length === 0) return;
	// get and hide msg coupon
	const inputCoupon = window.ctrwowCheckout.checkoutData.getCouponCode();
	const msgSuccess = document.querySelector('.coupon-msg .success');
	const msgError = document.querySelector('.coupon-msg .error');
	msgError && (msgError.style.display = 'none');
	msgSuccess && (msgSuccess.style.display = 'none');
	if (inputCoupon === couponCode) {
		msgSuccess && (msgSuccess.style.display = 'block');
	}
	// end
	
	const elmShippingProtect = document.querySelector('.shipping-protect input');
	const elmShippingProtectSummary = document.querySelector('.sum-insureship');
	if(!elmShippingProtect || !elmShippingProtect.checked){
		elmShippingProtectSummary && elmShippingProtectSummary.classList.add('js-hidden');
	}else {
		elmShippingProtectSummary && elmShippingProtectSummary.classList.remove('js-hidden');
	}
	
	const elmSummaryItemsParent = document.querySelector(`.${DATA_SETTING.summaryGroupClass} .${DATA_SETTING.summaryItemsProductClass}`);
	!elmSummaryItemTemplate && (elmSummaryItemTemplate = elmSummaryItemsParent.querySelector(`.${DATA_SETTING.summaryItemProductClass}`).cloneNode(true));
	
	let price = 0, fullPrice = 0, countItem = 0, shipping = 0;
		
	elmSummaryItemsParent.innerHTML = '';
	const firstTemp = elmSummaryItemTemplate.cloneNode(true);
	bindData2CartItem(arrCart[0], firstTemp, 0);
	elmSummaryItemsParent.appendChild(firstTemp);

	price += arrCart[0].product.productPrices.DiscountedPrice.Value;
	fullPrice += arrCart[0].product.productPrices.FullRetailPrice.Value;
	countItem += arrCart[0].qty;
	shipping += arrCart[0].product.shippings[window.shippingIndex || 0].price;
	
	
	//for gift
	const elmSummaryGiftsParent = document.querySelector(`.${DATA_SETTING.summaryGroupClass} .${DATA_SETTING.summaryGiftGroupClass}`);
	//!elmSummaryGiftItemTemplate && (elmSummaryGiftItemTemplate = elmSummaryGiftsParent.querySelector(`.${DATA_SETTING.summaryGiftItemClass}`).cloneNode(true));
	!elmSummaryGiftItemTemplate && (elmSummaryGiftItemTemplate = elmSummaryGiftsParent.cloneNode(true));
	elmSummaryGiftsParent.innerHTML = '';
	const firstGiftTemp = elmSummaryGiftItemTemplate.cloneNode(true);
	bindData2CartGift(arrCart[0], firstGiftTemp, 0);
	elmSummaryGiftsParent.appendChild(firstGiftTemp);
	fullPrice += (giftPrice * arrCart[0].qty)*2;
	//countItem +=arrCart[0].qty;
	
	for(let i= 1; i < arrCart.length; i++){
		const info = arrCart[i];
		const temp = elmSummaryItemTemplate.cloneNode(true);
		bindData2CartItem(info, temp, i);
		elmSummaryItemsParent.appendChild(temp);
		price += info.product.productPrices.DiscountedPrice.Value;
		fullPrice += info.product.productPrices.FullRetailPrice.Value;
		countItem += arrCart[i].qty;
		shipping += info.product.shippings[window.shippingIndex || 0].price;
		
		//for gift
		const giftTemp = elmSummaryGiftItemTemplate.cloneNode(true);
		bindData2CartGift(info, giftTemp, 0);
		elmSummaryGiftsParent.appendChild(giftTemp);
		fullPrice += (giftPrice * info.qty)*2;
		// countItem +=info.qty;
	}
	countItem =  countItem * 3;

	//get mini price
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	mini.forEach(item => {
		price += item.productPrices.DiscountedPrice.Value;
		fullPrice += item.productPrices.FullRetailPrice.Value;
		countItem += 1;
		shipping += item.shippings[0].price;
	})
	
	if(inputCoupon === couponCode){
		price = price - 10*arrCart.length;
	}
	
	const elmTotalFullPrice = document.querySelector(`.${DATA_SETTING.cartTotalFullPriceClass}`);
	const elmSubPrice = document.querySelector(`.${DATA_SETTING.summarySubTotalClass}`);
	const elmShipPrice = document.querySelector(`.${DATA_SETTING.summaryShippingPriceClass}`);
	const elmTotalPrice = document.querySelector(`.${DATA_SETTING.summaryFullPriceClass}`);
	const elmSavePrice = document.querySelector(`.${DATA_SETTING.summaryGrandSaveClass}`);
	const elmCountItem = document.querySelector(`.${DATA_SETTING.summaryTotalCountClass}`);
	
	const elmTotalPriceChoose = document.querySelector(`.section-2 .${DATA_SETTING.summaryTotalPriceChoose}`);
	const elmTotalFullPriceChoose = document.querySelector(`.section-2 .${DATA_SETTING.summaryFullPriceChoose}`);
	
	elmCountItem && (elmCountItem.innerText = countItem);
	elmSubPrice && (elmSubPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	elmSavePrice && (elmSavePrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	
	if(shipping === 0){
		elmShipPrice && (elmShipPrice.innerText = 'FREE');
	} else {
		elmShipPrice && (elmShipPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	}
	elmTotalPrice && (elmTotalPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price + shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	
	elmTotalPriceChoose && (elmTotalPriceChoose.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price + shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	elmTotalFullPriceChoose && (elmTotalFullPriceChoose.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
}

// remove disable class when data loaded
function removeDisableClass(){
	const elmDisableClass = document.querySelectorAll('.disableCls');
	elmDisableClass.forEach(elm => {
		elm.classList.remove('disableCls');
	})
}

// update cart number in cart icon
function replaceCartNumberProduct(){
	
	const elmCartCount = document.querySelectorAll('.cart-count');
	let countPro = 0;
	arrCart.forEach(info => {
		countPro += info.qty;
	})
	
	// count gift
	countPro = countPro*3;
	
	//count mini
	window.ctrwowCheckout.checkoutData.getMiniUpsell().forEach(item => {
		countPro += 1
	})
	
	if(arrCart.length === 0){
		countPro = 0;
	}
	
	elmCartCount.forEach(elm => {
		elm.textContent = countPro;
	})
	
	const elmMaxQtyMess = document.querySelector(`.${DATA_SETTING.cartContentClass} .${DATA_SETTING.maxTotalQtyMessClass}`);
	elmMaxQtyMess && elmMaxQtyMess.classList.add('js-hidden');
	if (countPro === maxProduct) {
		elmMaxQtyMess && elmMaxQtyMess.classList.remove('js-hidden');
	}
    const qtyGifts = document.querySelectorAll('.qty-gift') 
    qtyGifts.forEach(elm => {
        elm.innerText = countPro;

    })
    const qtyGiftCarts = document.querySelectorAll('.qty-gift-cart input') 
    qtyGiftCarts.forEach(elm => {
        elm.value = countPro;
        
    })
}

function triggerCloseMiniCart(){
	const elmCartContent = document.querySelector(".cart-popup .cart-content");
	const elmPopup = document.querySelector('.cart-popup .popup_widget');
	elmPopup && elmPopup.addEventListener("click", (e) => {
	  if (!elmCartContent.contains(e.target)) {
		elmPopup.classList.remove('popup_widget--opened');
		document.querySelector('body').classList.remove('show-popup_widget');
	  }
	});
}

// show/hide mini cart
function triggerCartIconClick(){
	const emlCartIcon = document.querySelector('.cart-icon');
	emlCartIcon && emlCartIcon.addEventListener('click', () => {
		updateCartInfo();
	})
}

//check anf show payment button
function triggerCheckoutType(){
	const btnCheckoutCC = document.querySelector('button[name="checkoutWithCreditCardV1"]');
	const btnCheckoutPP = document.querySelector('.checkoutWithPaypal.button-choose');
	const elmTab = document.querySelector('.faq-payment');
	elmTab && elmTab.addEventListener('click', (e) => {
		setTimeout(() => {
			const elmPaypalTab = document.querySelector('.accordion__item--is-open .payment-pp');
			if (elmPaypalTab){
				btnCheckoutPP && btnCheckoutPP.classList.remove('js-hidden');
				btnCheckoutCC && btnCheckoutCC.classList.add('js-hidden');
				isPaypalPayment = true;
			} else {
				btnCheckoutPP && btnCheckoutPP.classList.add('js-hidden');
				btnCheckoutCC && btnCheckoutCC.classList.remove('js-hidden');
				isPaypalPayment = false;
			}
		},100)
	})
}

//apply coupon
function triggerCouponCode(){
	const btnCoupon = document.querySelector('.btn-couponcode');
	btnCoupon && btnCoupon.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		
		const inputCoupon = document.querySelector('.input-couponcode');
		const msgSuccess = document.querySelector('.coupon-msg .success');
		const msgError = document.querySelector('.coupon-msg .error');
		if (!inputCoupon) return;
		msgError && (msgError.style.display = 'none');
		msgSuccess && (msgSuccess.style.display = 'none');
		if (inputCoupon.value !== couponCode){
			msgError && (msgError.style.display = 'block');
			msgSuccess && (msgSuccess.style.display = 'none');
		} else {
			window.ctrwowCheckout.checkoutData.setCouponCode(couponCode);
			msgError && (msgError.style.display = 'none');
			msgSuccess && (msgSuccess.style.display = 'block');
			bindData2OrderSummary();
		}
	});
}

//trigger shipping type
function triggerShippingExpress(){
	const elmShippingOpt = document.querySelectorAll('.delivery-opts .wrap-opts .delivery-item');
	elmShippingOpt.forEach(opt => {
		opt.addEventListener('click', () => {
			setTimeout(() => {
				bindData2OrderSummary();
			}, 100);
		})
	})
}
  
function triggerVideo() {
    const btns = document.querySelectorAll('.guide-slider .slide-item .btn-play-video');
    const popup = document.querySelector('.guide-popup');
    const closeBtn = popup.querySelector('.close-popup');
    const popupVideo = popup.querySelector('video'); 
    const playImg = popup.querySelector('.play-img');
 
    popupVideo.addEventListener('play', () => {
        if (playImg) playImg.style.display = 'none';
    });
 
    popupVideo.addEventListener('pause', () => {
        if (playImg) playImg.style.display = 'block';
    });
 
    if (playImg) {
        playImg.addEventListener('click', () => {
            popupVideo.play();
        });
    }
 
    btns.forEach((btn) => {
        btn.addEventListener('click', () => {
            const slideVideo = btn.closest('.slide-item').querySelector('video');
            if (!slideVideo || !popupVideo) return;
 
            popupVideo.src = slideVideo.currentSrc || slideVideo.src;
            popupVideo.play();
        });
    });
 
    closeBtn.addEventListener('click', () => {
        if (popupVideo) {
            popupVideo.pause();
        }
    });
}

function listener(){
	const session1 = document.querySelector(".section-1");
	const session2 = document.querySelector(".section-2");
	const btnProcess = document.querySelectorAll(".proceed-btn");

	Array.prototype.slice.call(btnProcess).forEach(item => {
		item.addEventListener("click", function(){
			// update product and price to checkout screen
			bindData2OrderSummary();
			session1 && session1.classList.add("js-hidden");
			session2 && session2.classList.remove("js-hidden");
			session2.scrollIntoView({behavior: "smooth"});
			
			//add param when change to checkoutview
			window.ctrwowUtils.handleParam.addParamIntoUrl('view','checkout');
			isCheckoutView = true;
		})
	})
	
	const btnEdits = document.querySelectorAll(".btn-edit-product");
	btnEdits.forEach(btnEdit => {
		btnEdit.addEventListener("click", function(){
			session1 && session1.classList.remove("js-hidden");
			session2 && session2.classList.add("js-hidden");
		  
			setTimeout(function(){
				isCheckoutView = false;
				const elmMiniCart = document.querySelector('.section-1 .cart-icon');
				elmMiniCart && elmMiniCart.click();
				
				const guideSlide = document.querySelector('.guide-slider .main-slider');
				guideSlide && guideSlide?.slick?.setPosition();
				
				const topSlide = document.querySelector('.top-slider .main-slider');
				topSlide && topSlide?.slick?.setPosition();
				
				
				const selectGroup = document.querySelector(".return-here");
				selectGroup && selectGroup.scrollIntoView({
					behavior: "smooth"
				});
			},200);
		})
	})
	
	
	// trigger buttin add to cart
	triggerAddToCart();
	triggerCloseMiniCart();
	triggerCheckoutType();
	triggerCouponCode();
	triggerShippingExpress();
    triggerVideo();
    // triggerSizeChange();
}

// trigger back button of browser
window.addEventListener("popstate", (event) => {
	const session2 = document.querySelector('.section-2');
	if(isCheckoutView && !session2.classList.contains('js-hidden')){
		const session1 = document.querySelector(".section-1");
		const session2 = document.querySelector(".section-2");
		const selectGroup = document.querySelector(".return-here");
		session1 && session1.classList.remove("js-hidden");
		session2 && session2.classList.add("js-hidden");
		history.pushState({}, "", location.href)
		setTimeout(function(){
			const guideSlide = document.querySelector('.guide-slider .main-slider');
			guideSlide && guideSlide?.slick?.setPosition();
			selectGroup && selectGroup.scrollIntoView({
				behavior: "smooth"
			});
		},200);
	}
	isCheckoutView = false;
});
  
//trigger click FAQ
function triggerFAQ(){
	const elmDescPros = document.querySelectorAll('.desc-pro .js-accordion__item');
    elmDescPros.forEach(item => {
        item.addEventListener('click', (e) => {
            setTimeout(() => {
                const elmOpen = document.querySelector('.desc-pro .js-accordion__item.accordion__item--is-open');
                elmOpen && elmOpen.scrollIntoView({behavior:'smooth'})
            },100);
        })
    })

	const elmAllFAQs = document.querySelectorAll('.accordion__item');
	elmAllFAQs.forEach(item => {
		if(!item.closest('.faq-payment')){
			item.addEventListener('click', (e) => {
				setTimeout(() => {
					const elmTab = document.querySelectorAll('.faq-payment .js-accordion__item');
					if(isPaypalPayment && elmTab.length > 1){
						elmTab[1].classList.add('accordion__item--is-open');
					}else if(elmTab.length > 0){
						elmTab[0].classList.add('accordion__item--is-open');
					}
				},100)
				
			})
		}
	})
}

function bindValueToOption(){
	const elmOpt1 = document.querySelectorAll(`.${DATA_SETTING.opt1Class}`);
	const opt1Value = DATA_SETTING.opt1Value?.split(',');
	const opt1Label = DATA_SETTING.opt1Label?.split(',');
	if (elmOpt1 && opt1Value && opt1Value.length === elmOpt1.length) {
		elmOpt1.forEach((opt1, index) => {
			opt1.setAttribute('data-value', opt1Value[index].trim());
			opt1.setAttribute('data-label', opt1Label[index].trim());
		})
	}
	
	const elmOpt2 = document.querySelectorAll(`.${DATA_SETTING.opt2Class}`);
	const opt2Value = DATA_SETTING.opt2Value?.split(',');
	const opt2Label = DATA_SETTING.opt2Label?.split(',');
	if (elmOpt2 && opt2Value && opt2Value.length === elmOpt2.length) {
		elmOpt2.forEach((opt2, index) => {
			opt2.setAttribute('data-value', opt2Value[index].trim());
			opt2.setAttribute('data-label', opt2Label[index].trim());
		})
	}
}
bindValueToOption();

// trigger change qty from Quantity Button widget
window.ctrwowUtils.events.on('triggerDoubleQuantity_FinishedChangeQty', () => {
	getPriceWithOptionSelect();
})

window.ctrwowUtils.events.on('triggerAddOnProductSelect', (data) => {
	setTimeout(() => {
		updateCartInfo();
	}, 100);
})

window.ctrwowUtils.getDependencies([window.ctrwowUtils.getCtrLibLink('ctrwowCheckout')], {
    delayUntilInteract: false
}).then(()=>window.ctrwowCheckout.ready().then(()=>{
    window.ctrwowCheckout.productListData.onProductListChange((products)=>{
        resetSize();
		removeDisableClass();
		getPriceWithOptionSelect();
      
      
    })
	window.ctrwowCheckout.checkoutData.onProductChange(() => {
      	//RedirectToOtherConfirm page
       	localStorage.setItem("redirectToOtherConfirm","confirm-miracle.html");
		updateLayoutWithSelectOption(1);
	})
}));

window.ctrwowUtils.events.on('onBeforeActivePopup', () => {
	updateAllCampaignWithCoupon();
	getPriceWithOptionSelect();
})
  
window.addEventListener("load", () => {
    updateDiscountPercent();
	listener();
	resetSize();
    triggerFAQ();
	getAllCampaign();
});

const isChangeImage = true;

function showPurchaseImage(){
	let qty = 0;
	arrCart.forEach(item => {
		qty += item.qty;
	})
	const elmImgGroups = document.querySelectorAll('.extra-popup .img-summary .img-smr');
	elmImgGroups.forEach(grp => {
		grp.classList.add('js-hidden');
	})
	
	const elmCurrentImgGroups = document.querySelectorAll(`.extra-popup .img-summary .img-smr.img-summary-${qty}`);
	elmCurrentImgGroups.forEach(grp => {
		grp.classList.remove('js-hidden');
	})
	
	let indexThumb = 0;
	let desc = '';
	arrCart.forEach((item,index) => {
		const opt1 = item.opt1.toLocaleLowerCase();
		if(desc !== '') desc += '<br/>';
		desc += `${item.qty}x ${item.opt2} | ${item.opt1}`;
		elmCurrentImgGroups.forEach(grp => {
			const elmThumbs = grp.querySelectorAll('.thumb-options');
			for(let i = indexThumb; i < elmThumbs.length; i++){
				if(i === indexThumb + item.qty) break;
				const currThumb = elmThumbs[i];
				currThumb.classList.remove(`thumb-option-white`);
				currThumb.classList.remove(`thumb-option-cream`);
				currThumb.classList.remove(`thumb-option-gray`);
				currThumb.classList.add(`thumb-option-${opt1}`);
			}
		})
		indexThumb = indexThumb + item.qty;
	})
	
	const elmDesc = document.querySelector('.extra-popup .pro-desc');
	elmDesc && (elmDesc.innerHTML = desc);
}

let isAddNewPro = false
function updatePricePurchase(){
	showPurchaseImage();
	const elmDropdownOption1 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass1}`);
	const elmDropdownOption2 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass2}`);
	if(!window.miniUpsells) return;
	
	const pro = window.miniUpsells.find(p => {
		return p.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${elmDropdownOption1.value.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1
        && p.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${elmDropdownOption2.value.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1;
    
	})
	if (!pro) return;
	const elmPurchasePrice = document.querySelectorAll(`.extra-popup .${purchasePriceClass}`);
	elmPurchasePrice.forEach(elm => {
		elm.innerText = pro.productPrices.DiscountedPrice.FormattedValue;
	})
    const fullPricePur = document.querySelector('.ordered-full-price-selected');
    const finalPricePur = document.querySelector('.ordered-price-selected');
    let fullPrice = 0
    let price = 0
    arrCart.forEach(itm => {
        fullPrice += itm.product.productPrices.FullRetailPrice.Value
        price += itm.product.productPrices.DiscountedPrice.Value
    })
    fullPricePur.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice,pro.productPrices.DiscountedPrice.FormattedValue)
    finalPricePur.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price,pro.productPrices.DiscountedPrice.FormattedValue)
	
	if (!isAddNewPro) {
        isAddNewPro = true;
        window.miniUpsells.unshift(JSON.parse(JSON.stringify(pro)));
    } else {
        window.miniUpsells[0] = pro;
    }
}


function triggerChangeOptionPurchase(){
	const elmOptions1 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass1}`);
    elmOptions1 && elmOptions1.addEventListener("change", (e) => {
		updatePricePurchase();
		// updatePurchaseImageProduct(isOption1ChangeImage, 1);
	})

    const elmOptions2 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass2}`);
    elmOptions2 && elmOptions2.addEventListener("change", (e) => {
		updatePricePurchase();
		const opt = e.currentTarget.value.toLocaleLowerCase();
		const elmExtraImg = document.querySelector(`.extra-popup .img-smr:not(.js-hidden) .extra-img`);
		if(elmExtraImg){
			elmExtraImg.classList.remove(`thumb-option-white`);
			elmExtraImg.classList.remove(`thumb-option-cream`);
			elmExtraImg.classList.remove(`thumb-option-gray`);
			elmExtraImg.classList.add(`thumb-option-${opt}`);
		}
	})
}

triggerChangeOptionPurchase();

window.ctrwowUtils.events.on('triggerFinishOrder', updatePricePurchase);
window.ctrwowUtils.events.on('triggerPaypalOrder', updatePricePurchase);
</script>