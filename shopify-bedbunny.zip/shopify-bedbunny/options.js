
// get product with option
function getProduct(obj, isPurchase = false, isMainScreen = false ){
	if(!window.localStorage.getItem('products')) return;
	
	let totalQty = 0;
	if(isMainScreen){
		totalQty = parseInt(document.querySelector('.main-screen input.numberTxt').value)
	} else {
		arrCart.forEach(item => {
			totalQty += item.qty;
		})
	}
	
	if(totalQty === 0) totalQty = obj.qty;
	const products = getCurrentMainProduct(totalQty);
	const pro = products.find(pro => {
		return 	pro.quantity === obj.qty && 
				pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${obj.opt1.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1 && 
				pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt2Begin}${obj.opt2.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt2End}`) > -1;
	})
	if(pro){
		obj.product = pro;
		return pro;
	}
	
	return null;
}

// get gift with option

function getGiftProductBeforeSubmit(){
	if(!window.miniUpsellsWidget) return;
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	arrCart.forEach(obj => {
		const pro = window.miniUpsellsWidget.find(pro => {
			return 	pro.quantity === obj.qty && 
					pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${obj.opt1.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1 && 
					pro.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt2Begin}${obj.opt2.toLocaleLowerCase() === 'xs' ? 's/m' : obj.opt2.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt2End}`) > -1;
		})
		
		if(pro){
			mini.push({productId: pro.productId, shippingMethodId: pro.shippings[0].shippingMethodId})
		}
	})
	
	window.ctrwowCheckout.checkoutData.setMiniUpsell(mini);
}

function getShipping(qty, obj, isMain){
	switch(qty){
		case 2:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey2Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey2Units[2];
			}
			window.__ctrPageConfiguration.webKey = webkey2Units;
            
			break;
		case 3:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[2];
			} else if(obj.qty === 3){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey3Units[3];
			}
			window.__ctrPageConfiguration.webKey = webkey3Units;
            break;
		case 4:
			if(obj.qty === 1){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[1];
			} else if(obj.qty === 2){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[2];
			} else if(obj.qty === 3){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[3];
			} else if(obj.qty === 4){
				obj.product.shippings[0].shippingMethodId = shippingIds.webkey4Units[4];
			}
			window.__ctrPageConfiguration.webKey = webkey4Units;
            break;
	}
	
	//set location to local storage with new webkey
	if(isMain){
		let campProducts = window.localStorage.getItem('campproducts');
		campProducts = campProducts ? JSON.parse(campProducts) : [];
		const isExistCamps = campProducts.camps.filter(camp => {
			return camp[window.__ctrPageConfiguration.webKey];
		});
		if(!isExistCamps || isExistCamps.length === 0){
			const obj = {};
			obj[window.__ctrPageConfiguration.webKey] = window.__productListData.data.productList;
			campProducts.camps.push(obj);
			window.localStorage.setItem('campproducts', JSON.stringify(campProducts));
		}
	}
	return obj.product.shippings;
}



function triggerFirstChangeOpt1(){
	const elmOpt1s = document.querySelectorAll(`.${DATA_SETTING.opt1Class}`);
	const elmOpt1Label = document.querySelector(`.${DATA_SETTING.opt1LabelClass}`);
	const elmOpt1Bottom = document.querySelectorAll(`.sticky-bar .${DATA_SETTING.stickyBarOpt1Class}`);
	const elmOpt1DropdownBottom = document.querySelector(`.sticky-bar .${DATA_SETTING.stickyBarOpt1DropdownClass}`);
	const elmOpt1Sliders = document.querySelectorAll(`.widget-slider.${DATA_SETTING.opt1ShowClass}`);
	elmOpt1s.forEach(item => {
		item.addEventListener('click', (e) => {
			elmOpt1s.forEach(el => {
				el.classList.remove('active');
			})
			e.currentTarget.classList.add('active');
			elmOpt1Label.innerText = item.dataset.label;
			
			getPriceWithOptionSelect();
			
			elmOpt1Bottom.forEach(e => {
				e.classList.add('js-hidden');
			})
			
			const currentImg = document.querySelector(`.sticky-bar img.${item.dataset.value.toLocaleLowerCase()}-show`);
			currentImg && currentImg.classList.remove('js-hidden');
			
			elmOpt1DropdownBottom && (elmOpt1DropdownBottom.value = item.dataset.value);
			
			/*// show/hide slider
			elmOpt1Sliders.forEach(s => {
				s.classList.add('js-hidden');
			})
			
			const currentSlider = document.querySelector(`.widget-slider.${item.dataset.value.toLocaleLowerCase()}-show`);
			currentSlider && currentSlider.classList.remove('js-hidden');
			const mainSlider = currentSlider.querySelector('.main-slider');
			mainSlider && mainSlider?.slick?.setPosition();*/
			
			//scorll to slider
			const currentSlider = document.querySelector(`.slick-track .slide-${item.dataset.value.toLocaleLowerCase()}`);
			currentSlider && currentSlider.click();
		})
	})
	
	elmOpt1DropdownBottom && elmOpt1DropdownBottom.addEventListener('change', (e) => {
		const value = e.currentTarget.value;
		const elmOption1 = document.querySelector(`.${DATA_SETTING.opt1Class}[data-value="${value}"]`);
		elmOption1 && elmOption1.click();
	})
	
}
triggerFirstChangeOpt1();

function triggerFirstChangeOpt2(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size select');
	const elmOpt2DropdownBottom = document.querySelector(`.sticky-bar .${DATA_SETTING.stickyBarOpt2DropdownClass}`);
        elmSizeOptions.forEach((elm) => {

            elm.addEventListener('change', (e)=>{
                const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
                updateLayoutWithSelectOption(qty);
                if (e.currentTarget.closest('.size-1')){
                    elmOpt2DropdownBottom.value = e.currentTarget.value;

                }

            })
        })
        elmOpt2DropdownBottom && elmOpt2DropdownBottom.addEventListener('change', (e) => {
            const value = e.currentTarget.value;
            const elmOption2 = document.querySelector('.option-group .size-box .size-1 select');
            if (elmOption2){
                elmOption2.value = value;
                elmOption2.dispatchEvent(new Event('change'))
            }
        }
        )

}
triggerFirstChangeOpt2();

// update price and get product info
function getFirstProductPrice(color, size, lblSize, img){
	const productInfo = {color: color, size: size, qty: 1, lblSize: lblSize, img: img};
	const product = getProduct(productInfo, false);
	if(product){
		const groupItem = document.querySelector('body');
		bindPriceToLayout(product, groupItem, 'discount-price-choose', 'full-price-choose', 'saving-price-choose', true);
	}
}

function getPriceWithOptionSelect(){
	const arrP = [];
    let firstPro = null;

	const elmOpt1 = document.querySelector(`.${DATA_SETTING.opt1ActiveClass}`);
	const elmImg = document.querySelector(`.${DATA_SETTING.opt1ActiveClass} img`);
	// const elmOpt2 = document.querySelector(`.${DATA_SETTING.opt2ActiveClass}`);
	const opt1Value = elmOpt1?.dataset.value;
	// const opt2Value = elmOpt2?.dataset.value;
	const lblOpt1 = elmOpt1?.dataset.label;
	// const lblOpt2 = elmOpt2?.dataset.label;
	
	if(!opt1Value) return
	const elmOpt2s =  document.querySelectorAll('.option-group .size-box .size:not(.js-hidden)')

    elmOpt2s.forEach(elmOpt2 => {
        const opt2Value = elmOpt2.querySelector('select').value;
        const lblOpt2 = opt2Value

        // const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
        const qty = 1;
        const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: qty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmImg?.src};
		
		let isExistsPro = arrP.find(p => {
			return p.opt1 === opt1Value && p.opt2 === opt2Value;
		})
		
		if(isExistsPro){
			isExistsPro.qty += qty;
			getProduct(isExistsPro, false, true);
		}else {
			const product = getProduct(productInfo, false, true);
			if(product){
				if (firstPro === null) {
					firstPro= product;

				}
				arrP.push(productInfo);
			}
		}
    })
	
	let totalFullMainPrice = 0, totalMainPrice = 0;
	arrP.forEach(p => {
		totalFullMainPrice += p.product.productPrices.FullRetailPrice.Value;
		totalMainPrice += p.product.productPrices.DiscountedPrice.Value;
	})
	
	const elmTotalMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalPriceMainScreenClass}`);
	elmTotalMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmTotalFullMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalFullPriceMainScreenClass}`);
	elmTotalFullMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalFullMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmSaveMainPrice = document.querySelectorAll(`.${DATA_SETTING.totalSavePriceMainScreenClass}`);
	elmSaveMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(totalFullMainPrice - totalMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	
	//show price for floating bar
	// const product1UnitInfo = {opt1: opt1Value, opt2: opt2Value, qty: 1, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmImg?.src};
	const product1Unit = firstPro //getProduct(product1UnitInfo, false, true);
	
	if(!product1Unit) return
	
	
	let fullMainPrice = 0, mainPrice = 0;
	fullMainPrice += product1Unit.productPrices.FullRetailPrice.Value;
	mainPrice += product1Unit.productPrices.DiscountedPrice.Value;
	
	const elmMainPrice = document.querySelectorAll(`.${DATA_SETTING.priceMain1UnitClass}`);
	elmMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(mainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmFullMainPrice = document.querySelectorAll(`.${DATA_SETTING.fullPriceMain1UnitClass}`);
	elmFullMainPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullMainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
	
	const elmSavePrice = document.querySelectorAll(`.${DATA_SETTING.savePriceMain1UnitClass}`);
	elmSavePrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullMainPrice - mainPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	});
}

function updateLayoutWithSelectOption(qty){
	getPriceWithOptionSelect();
	updateCartInfo();
}

function updateSizeOption(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size');
    const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
    elmSizeOptions.forEach((elm,index) => {
        if (index<qty){
            elm.classList.remove('js-hidden')

        } else {
            elm.classList.add('js-hidden')
        }
    })
    
}


function triggerSizeChange(){
    const elmSizeOptions = document.querySelectorAll('.option-group .size-box .size select');
    elmSizeOptions.forEach((elm) => {
        elm.addEventListener('change', ()=>{
            const qty = parseInt(document.querySelector('.main-screen input.numberTxt').value);
            updateLayoutWithSelectOption(qty);
            

        })
    })
    elmOpt2DropdownBottom && elmOpt2DropdownBottom.addEventListener('change', (e) => {
        const value = e.currentTarget.value;
        const elmOption2 = document.querySelector(`.${DATA_SETTING.opt2Class}[data-value="${value}"]`);
        elmOption2 && elmOption2.click();
    }
    )

}

function bindValueToOption(){
	const elmOpt1 = document.querySelectorAll(`.${DATA_SETTING.opt1Class}`);
	const opt1Value = DATA_SETTING.opt1Value?.split(',');
	const opt1Label = DATA_SETTING.opt1Label?.split(',');
	if (elmOpt1 && opt1Value && opt1Value.length === elmOpt1.length) {
		elmOpt1.forEach((opt1, index) => {
			opt1.setAttribute('data-value', opt1Value[index].trim());
			opt1.setAttribute('data-label', opt1Label[index].trim());
		})
	}
	
	const elmOpt2 = document.querySelectorAll(`.${DATA_SETTING.opt2Class}`);
	const opt2Value = DATA_SETTING.opt2Value?.split(',');
	const opt2Label = DATA_SETTING.opt2Label?.split(',');
	if (elmOpt2 && opt2Value && opt2Value.length === elmOpt2.length) {
		elmOpt2.forEach((opt2, index) => {
			opt2.setAttribute('data-value', opt2Value[index].trim());
			opt2.setAttribute('data-label', opt2Label[index].trim());
		})
	}
}
bindValueToOption();

// trigger change qty from Quantity Button widget
window.ctrwowUtils.events.on('triggerDoubleQuantity_FinishedChangeQty', () => {
	getPriceWithOptionSelect();
})



window.ctrwowUtils.events.on('triggerAddOnProductSelect', (data) => {
	setTimeout(() => {
		updateCartInfo();
	}, 100);
})

window.ctrwowUtils.getDependencies([window.ctrwowUtils.getCtrLibLink('ctrwowCheckout')], {
    delayUntilInteract: false
}).then(()=>window.ctrwowCheckout.ready().then(()=>{
    window.ctrwowCheckout.productListData.onProductListChange((products)=>{
        resetSize();
		removeDisableClass();
		getPriceWithOptionSelect();
      
      
    })
	window.ctrwowCheckout.checkoutData.onProductChange(() => {
      	//RedirectToOtherConfirm page
       	localStorage.setItem("redirectToOtherConfirm","confirm-miracle.html");
		updateLayoutWithSelectOption(1);
	})
}));

window.ctrwowUtils.events.on('onBeforeActivePopup', () => {
	updateAllCampaignWithCoupon();
	getPriceWithOptionSelect();
})