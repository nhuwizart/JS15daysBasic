
function validatePurchaseData(){
	const elmError = document.querySelector(".extra-item .error-size");
	const elmSizes = document.querySelectorAll(".extra-item .size-dropdown") || [];
	const elmColors = document.querySelectorAll(".extra-item select.color-dropdown") || [];
	let isValidateSize = true;
	for(let i=0; i< elmSizes.length; i++){
		const itemSize = elmSizes[i];
		const itemColor = elmColors[i];
		if(!itemSize.value || !itemColor.value){
			isValidateSize = false;
			elmError && elmError.classList.remove("js-hidden");
			return;
		}
		
		const isExistIndex = arrSizePurchase.findIndex(obj => {
			return obj.size === itemSize.value && obj.color === itemColor.value;
		})
		
		if(isExistIndex === -1){
			const obj = {
				size: itemSize.value,
				color: itemColor.value,
				qty: 1
			}
			arrSizePurchase.push(obj);
		} else {
			arrSize[isExistIndex].qty += 1;
		}
	}
	Array.prototype.slice.call(elmSizes).forEach(item => {
		if(!item.value) {
			isValidateSize = false;
			elmError && elmError.classList.remove("js-hidden");
			return;
		}
		
		const isExistIndex = arrSizePurchase.findIndex(obj => {
			return obj.size === item.value;
		})
		
		if(isExistIndex === -1){
			const obj = {
				size: item.value,
				qty: 1
			}
			arrSizePurchase.push(obj);
		} else {
			arrSizePurchase[isExistIndex].qty += 1;
		}
	})
	
	return isValidateSize;
}

function bindPurchaseDataWithSize(){
	let qty = 0;
	arrSizePurchase.forEach(obj => {
		getProduct(obj, true);
		qty+=obj.qty;
	})
	arrSizePurchase.sort((obj1, obj2) => {
		return obj2.qty - obj1.qty;
	})
	
	const currentProduct = window.miniUpsells[0];
	currentProduct.productId = arrSizePurchase[0].product.productId;
	
	window.multipleMiniUpsells = [];
	
	for(let i = 1; i < arrSizePurchase.length; i++){
		const obj = arrSizePurchase[i].product;
		const pro = {
			productId: obj.productId,
			shippingMethodId: shippings && shippings.length > 0 ? shippings[0].shippingMethodId : null,
			price: obj.productPrices.DiscountedPrice.Value,
			type: 'mini',
			addToSummary: false
		}
		window.multipleMiniUpsells.push(pro);
	}
}

const isChangeImage = true;

function showPurchaseImage(){
	let qty = 0;
	arrCart.forEach(item => {
		qty += item.qty;
	})
	const elmImgGroups = document.querySelectorAll('.extra-popup .img-summary .img-smr');
	elmImgGroups.forEach(grp => {
		grp.classList.add('js-hidden');
	})
	
	const elmCurrentImgGroups = document.querySelectorAll(`.extra-popup .img-summary .img-smr.img-summary-${qty}`);
	elmCurrentImgGroups.forEach(grp => {
		grp.classList.remove('js-hidden');
	})
	
	let indexThumb = 0;
	let desc = '';
	arrCart.forEach((item,index) => {
		const opt1 = item.opt1.toLocaleLowerCase();
		if(desc !== '') desc += '<br/>';
		desc += `${item.qty}x ${item.opt2} | ${item.opt1}`;
		elmCurrentImgGroups.forEach(grp => {
			const elmThumbs = grp.querySelectorAll('.thumb-options');
			for(let i = indexThumb; i < elmThumbs.length; i++){
				if(i === indexThumb + item.qty) break;
				const currThumb = elmThumbs[i];
				currThumb.classList.remove(`thumb-option-white`);
				currThumb.classList.remove(`thumb-option-cream`);
				currThumb.classList.remove(`thumb-option-gray`);
				currThumb.classList.add(`thumb-option-${opt1}`);
			}
		})
		indexThumb = indexThumb + item.qty;
	})
	
	const elmDesc = document.querySelector('.extra-popup .pro-desc');
	elmDesc && (elmDesc.innerHTML = desc);
}

let isAddNewPro = false
function updatePricePurchase(){
	showPurchaseImage();
	const elmDropdownOption1 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass1}`);
	const elmDropdownOption2 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass2}`);
	if(!window.miniUpsells) return;
	
	const pro = window.miniUpsells.find(p => {
		return p.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${elmDropdownOption1.value.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1
        && p.productName.toLocaleLowerCase().indexOf(`${DATA_SETTING.bracketsOpt1Begin}${elmDropdownOption2.value.toLocaleLowerCase()}${DATA_SETTING.bracketsOpt1End}`) > -1;
    
	})
	if (!pro) return;
	const elmPurchasePrice = document.querySelectorAll(`.extra-popup .${purchasePriceClass}`);
	elmPurchasePrice.forEach(elm => {
		elm.innerText = pro.productPrices.DiscountedPrice.FormattedValue;
	})
    const fullPricePur = document.querySelector('.ordered-full-price-selected');
    const finalPricePur = document.querySelector('.ordered-price-selected');
    let fullPrice = 0
    let price = 0
    arrCart.forEach(itm => {
        fullPrice += itm.product.productPrices.FullRetailPrice.Value
        price += itm.product.productPrices.DiscountedPrice.Value
    })
    fullPricePur.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice,pro.productPrices.DiscountedPrice.FormattedValue)
    finalPricePur.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price,pro.productPrices.DiscountedPrice.FormattedValue)
	
	if (!isAddNewPro) {
        isAddNewPro = true;
        window.miniUpsells.unshift(JSON.parse(JSON.stringify(pro)));
    } else {
        window.miniUpsells[0] = pro;
    }
}


function triggerChangeOptionPurchase(){
	const elmOptions1 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass1}`);
    elmOptions1 && elmOptions1.addEventListener("change", (e) => {
		updatePricePurchase();
		// updatePurchaseImageProduct(isOption1ChangeImage, 1);
	})

    const elmOptions2 = document.querySelector(`.extra-popup .${purchaseDropdownOptionClass2}`);
    elmOptions2 && elmOptions2.addEventListener("change", (e) => {
		updatePricePurchase();
		const opt = e.currentTarget.value.toLocaleLowerCase();
		const elmExtraImg = document.querySelector(`.extra-popup .img-smr:not(.js-hidden) .extra-img`);
		if(elmExtraImg){
			elmExtraImg.classList.remove(`thumb-option-white`);
			elmExtraImg.classList.remove(`thumb-option-cream`);
			elmExtraImg.classList.remove(`thumb-option-gray`);
			elmExtraImg.classList.add(`thumb-option-${opt}`);
		}
	})
}

triggerChangeOptionPurchase();

window.ctrwowUtils.events.on('triggerFinishOrder', updatePricePurchase);
window.ctrwowUtils.events.on('triggerPaypalOrder', updatePricePurchase);