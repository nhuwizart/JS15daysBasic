
function triggerPaymentButton(){
	const elmBtns = document.querySelectorAll(".paypal-placeholder, button[name='checkoutWithCreditCardV1']");
	Array.prototype.slice.call(elmBtns).forEach(btn => {
		btn.addEventListener("click", function(e){
			bindData4Checkout()
		})
	})

	const elmRealPP = document.querySelectorAll("button.checkoutWithPaypal");
	Array.prototype.slice.call(elmRealPP).forEach(btn => {
		btn.addEventListener("click", function(e){
			//getGiftProductBeforeSubmit();
			bindData4Checkout();
		})
	})
	
	const elmAddPurchase = document.querySelectorAll(".popup_widget_content .btn-add-purchase");
	Array.prototype.slice.call(elmAddPurchase).forEach(btn => {
		btn.addEventListener("click", function(e){
			
			if(!validatePurchaseData()){
				e.preventDefault();
				e.stopImmediatePropagation();
				e.stopPropagation();
				return;
			}
			
			bindPurchaseDataWithSize();
			const elmPurchase = document.querySelector(".popup_widget_content .btn-add");
			elmPurchase && elmPurchase.click();
		})
	})
}
triggerPaymentButton();

window.ctrwowUtils.events.on("ctr_form_checkoutWithCreditCardV1", (data) => {
	if(data.customer){
		//getGiftProductBeforeSubmit();
	}
})
