function triggerExitPopup(){
	const elmBtns = document.querySelectorAll(".close-expopup-and-active, .popup-activate__btn-yes");
	elmBtns.forEach(elm => {
		elm.addEventListener("click", () => {
			getPriceWithOptionSelect();
		})
	})
}