
function updateDiscountPercent(){
	const elmBtnActiveCoupon = document.querySelectorAll(".popup-activate .js__btn-yes,.popup-activate .js__btn-close-and-active,.popup-activate .close-expopup-and-active");
  		
  	Array.prototype.slice.call(elmBtnActiveCoupon).forEach(item => {
    	item.addEventListener("click", function(){
          const elmPercentDefault = document.querySelectorAll(".js-list .js-list-item");
          
          Array.prototype.slice.call(elmPercentDefault).forEach(item => {
              const discount = item.querySelector(".discount-percent");
			  const discountCoupon = item.querySelector(".discount-percent-apply-coupon");
			  discount && discountCoupon && (discount.innerText = discountCoupon.innerText);
          })
		  
		  const currentPercent = document.querySelector('.list .list-item--checked .discount-percent');
		  const elmPerPriceChoose = document.querySelector(".percent-price-choose");
		  currentPercent && elmPerPriceChoose && (elmPerPriceChoose.innerText = currentPercent.innerText);
		  
          const elmMsgBeforeApply = document.querySelector(".msg-before-coupon-apply");
		  elmMsgBeforeApply &&  (elmMsgBeforeApply.style.display = "none");

		  const elmMsgAfterApply = document.querySelector(".msg-after-coupon-apply");
		  elmMsgAfterApply &&  (elmMsgAfterApply.style.display = "block");
          
          const elmAfterApplyChoose = document.querySelector(".coupon-apply-choose");
		  elmAfterApplyChoose &&  (elmAfterApplyChoose.style.display = "inline");
		  
		  setTimeout(() => {
			  const qty = parseInt(document.querySelector('.main-screen .numberTxt').value)
			  updateDiscountValue(qty);
		  }, 200)
      })
    })	 
    
} 

function getCurrentMainProduct(qty){
	let pro = null;
	switch (qty){
		case 1:
			pro = JSON.parse(window.localStorage.getItem('products'));
			break;
		case 2:
			pro = campaign2Info ? campaign2Info.prices : null;
			break;
		case 3:
			pro = campaign3Info ? campaign3Info.prices : null;
			break;
		case 4:
			pro = campaign4Info ? campaign4Info.prices : null;
			break;
		default:
			break;
	}
	
	return pro;
}

function getCurrentMiniProduct(qty){
	let pro = null;
	switch (qty){
		case 1:
			pro = window.miniUpsellsWidget || null;
			break;
		case 2:
			pro = mini2Info || null;
			break;
		case 3:
			pro = mini3Info || null;
			break;
		case 4:
			pro = mini4Info || null;
			break;
		default:
			break;
	}
	
	return pro;
}

function bindData4Checkout(){
	arrCart.sort((obj1, obj2) => {
		return obj2.qty - obj1.qty;
	})
	
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	const currentProduct = window.ctrwowCheckout.checkoutData.getProduct();
	currentProduct.productId = arrCart[0].product.productId;
	
	window.multiMainProducts = null;
	let shippingIndex = window.shippingIndex || 0;
	if(arrCart.length >= 1){
		//currentProduct.shippings = arrCart[0].product.shippings;
		currentProduct.shippings = getShipping(totalQty, arrCart[0], true);
		const multiMainProducts = [];
		multiMainProducts.push({
			productId: currentProduct.productId,
			shippingMethodId: currentProduct.shippings && currentProduct.shippings.length > shippingIndex ? currentProduct.shippings[shippingIndex].shippingMethodId : null
		});
		
		localStorage.removeItem("extendedtext");
		
		for(let i = 1; i < arrCart.length; i++){
			const obj = arrCart[i].product;
			//const shippings = obj.shippings;
			const shippings = getShipping(totalQty, arrCart[i], true);
			const pro = {
				productId: obj.productId,
				shippingMethodId: shippings && shippings.length > 0 ? shippings[0].shippingMethodId : null
			}
			multiMainProducts.push(pro);
		}
		
		window.multiMainProducts = multiMainProducts;
	}
}

// reset size when load page
function resetSize(){
	const elmSizes = document.querySelectorAll(".size .size-option");
	Array.prototype.slice.call(elmSizes).forEach(item => {
		item.value = "Twin";
		
	})
	
	/*const elmColors = document.querySelectorAll(".color-dropdown");
	Array.prototype.slice.call(elmColors).forEach(item => {
		item.value = "Black";
		
	})*/
}

function updateDiscountValue(qty){
	const elmDiscountValue = document.querySelectorAll('.msg-before-coupon-apply .hb-value, .msg-after-coupon-apply .hb-value');
	let value = '50%';
	switch(qty){
		case 1:
			value = '50%';
			
			break;
		case 2:
			value = '50%';
			break;
		case 3:
			value = '60%';
			break;
		case 4:
			value = '62%';
			break;
	}
	
	elmDiscountValue.forEach(elm => {
		elm.innerText = value;
	})
}



function triggerAddMoreItemOnMain(){
	// add more  button
	const btnPlus = document.querySelector('.return-here span.plus');
	btnPlus && btnPlus.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		
		const elmParent = e.currentTarget.closest('.custom-number');
		if (!elmParent) return;
		
		
		
		const elmQty = elmParent.querySelector('input.numberTxt');
		let qty = elmQty ? parseInt(elmQty.value) : null;
		
		if(!qty || qty === maxProduct) return;
		qty += 1;
		
		
		if(qty >= maxProduct) {
			qty = maxProduct;
		}
		
		elmQty.value = qty;
        updateSizeOption();

		updateLayoutWithSelectOption(qty);
		updateDiscountValue(qty);
	})
	
	const btnMinus = document.querySelector('.return-here span.minus');
	btnMinus && btnMinus.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		const elmParent = e.currentTarget.closest('.custom-number');
		if (!elmParent) return;
		const elmQty = elmParent.querySelector('input.numberTxt');
		let qty = elmQty ? parseInt(elmQty.value) : null;
		
		if(!qty || qty === 1) return;
		qty -= 1;
		elmQty.value = qty;
		updateSizeOption();

		updateLayoutWithSelectOption(qty);
		updateDiscountValue(qty);
	})
	
}
triggerAddMoreItemOnMain();




// reUpdate Insurance Info
function reCalInsurancePrice() {
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	if(totalQty === 0) totalQty = 1;
	
	const pro = window.__productListData.data.productList.prices.find(p => {
		return p.quantity === totalQty
	})
	
    const currentPid = pro.productId;
    const insureshipPidListStr = document.querySelector(`.${DATA_SETTING.cartInsureshipContentClass}`);
    const insureshipPidSList = insureshipPidListStr ? JSON.parse(insureshipPidListStr.getAttribute('pid')) : null;
    if (!insureshipPidSList)
        return;

    const currentInsureshipPid = insureshipPidSList[currentPid];
    let insureshipPids = Object.values(insureshipPidSList);
    //convert pid to String
    insureshipPids = insureshipPids.map(String);

    let mini = window.ctrwowCheckout.checkoutData.getMiniUpsell();

    //remove insureship
    mini = mini.filter(item => {
        return insureshipPids.indexOf(item.productId.toString()) === -1;
    }
    )

    if (!currentInsureshipPid)
        return;
    const miniProduct = window.miniUpsellsWidget || window.miniUpsells;
    const currentInsureship = miniProduct.find(item => {
        return item.productId.toString() === currentInsureshipPid.toString();
    }
    )

    if (currentInsureship) {
        const elmPrices = insureshipPidListStr.querySelectorAll('.addon-price');
        const isChecked = insureshipPidListStr.querySelector('input');
        if (isChecked && isChecked.checked) {
            mini.push({
                productId: currentInsureship.productId,
                shippingMethodId: currentInsureship.shippings.length > 0 ? currentInsureship.shippings[0].shippingMethodId : null,
                productName: currentInsureship.productName,
                price: currentInsureship.price,
                productPrices: currentInsureship.productPrices,
                shippings: currentInsureship.shippings
            });
        }
        elmPrices.forEach(elmPrice => {
            elmPrice.innerText = currentInsureship.productPrices.DiscountedPrice.FormattedValue;
        })
		
		const elmSafeTrakPrice = document.querySelectorAll(`.${DATA_SETTING.summarySafeTrakPriceClass}`);
		elmSafeTrakPrice.forEach(elm => {
			elm.innerText = currentInsureship.productPrices.DiscountedPrice.FormattedValue;
		})

    }

    window.ctrwowCheckout.checkoutData.setMiniUpsell(mini);
}

// update product and price to checkout screen
function bindData2OrderSummary(){
	if (arrCart.length === 0) return;
	// get and hide msg coupon
	const inputCoupon = window.ctrwowCheckout.checkoutData.getCouponCode();
	const msgSuccess = document.querySelector('.coupon-msg .success');
	const msgError = document.querySelector('.coupon-msg .error');
	msgError && (msgError.style.display = 'none');
	msgSuccess && (msgSuccess.style.display = 'none');
	if (inputCoupon === couponCode) {
		msgSuccess && (msgSuccess.style.display = 'block');
	}
	// end
	
	const elmShippingProtect = document.querySelector('.shipping-protect input');
	const elmShippingProtectSummary = document.querySelector('.sum-insureship');
	if(!elmShippingProtect || !elmShippingProtect.checked){
		elmShippingProtectSummary && elmShippingProtectSummary.classList.add('js-hidden');
	}else {
		elmShippingProtectSummary && elmShippingProtectSummary.classList.remove('js-hidden');
	}
	
	const elmSummaryItemsParent = document.querySelector(`.${DATA_SETTING.summaryGroupClass} .${DATA_SETTING.summaryItemsProductClass}`);
	!elmSummaryItemTemplate && (elmSummaryItemTemplate = elmSummaryItemsParent.querySelector(`.${DATA_SETTING.summaryItemProductClass}`).cloneNode(true));
	
	let price = 0, fullPrice = 0, countItem = 0, shipping = 0;
		
	elmSummaryItemsParent.innerHTML = '';
	const firstTemp = elmSummaryItemTemplate.cloneNode(true);
	bindData2CartItem(arrCart[0], firstTemp, 0);
	elmSummaryItemsParent.appendChild(firstTemp);

	price += arrCart[0].product.productPrices.DiscountedPrice.Value;
	fullPrice += arrCart[0].product.productPrices.FullRetailPrice.Value;
	countItem += arrCart[0].qty;
	shipping += arrCart[0].product.shippings[window.shippingIndex || 0].price;
	
	
	//for gift
	const elmSummaryGiftsParent = document.querySelector(`.${DATA_SETTING.summaryGroupClass} .${DATA_SETTING.summaryGiftGroupClass}`);
	//!elmSummaryGiftItemTemplate && (elmSummaryGiftItemTemplate = elmSummaryGiftsParent.querySelector(`.${DATA_SETTING.summaryGiftItemClass}`).cloneNode(true));
	!elmSummaryGiftItemTemplate && (elmSummaryGiftItemTemplate = elmSummaryGiftsParent.cloneNode(true));
	elmSummaryGiftsParent.innerHTML = '';
	const firstGiftTemp = elmSummaryGiftItemTemplate.cloneNode(true);
	bindData2CartGift(arrCart[0], firstGiftTemp, 0);
	elmSummaryGiftsParent.appendChild(firstGiftTemp);
	fullPrice += (giftPrice * arrCart[0].qty)*2;
	//countItem +=arrCart[0].qty;
	
	for(let i= 1; i < arrCart.length; i++){
		const info = arrCart[i];
		const temp = elmSummaryItemTemplate.cloneNode(true);
		bindData2CartItem(info, temp, i);
		elmSummaryItemsParent.appendChild(temp);
		price += info.product.productPrices.DiscountedPrice.Value;
		fullPrice += info.product.productPrices.FullRetailPrice.Value;
		countItem += arrCart[i].qty;
		shipping += info.product.shippings[window.shippingIndex || 0].price;
		
		//for gift
		const giftTemp = elmSummaryGiftItemTemplate.cloneNode(true);
		bindData2CartGift(info, giftTemp, 0);
		elmSummaryGiftsParent.appendChild(giftTemp);
		fullPrice += (giftPrice * info.qty)*2;
		// countItem +=info.qty;
	}
	countItem =  countItem * 3;

	//get mini price
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	mini.forEach(item => {
		price += item.productPrices.DiscountedPrice.Value;
		fullPrice += item.productPrices.FullRetailPrice.Value;
		countItem += 1;
		shipping += item.shippings[0].price;
	})
	
	if(inputCoupon === couponCode){
		price = price - 10*arrCart.length;
	}
	
	const elmTotalFullPrice = document.querySelector(`.${DATA_SETTING.cartTotalFullPriceClass}`);
	const elmSubPrice = document.querySelector(`.${DATA_SETTING.summarySubTotalClass}`);
	const elmShipPrice = document.querySelector(`.${DATA_SETTING.summaryShippingPriceClass}`);
	const elmTotalPrice = document.querySelector(`.${DATA_SETTING.summaryFullPriceClass}`);
	const elmSavePrice = document.querySelector(`.${DATA_SETTING.summaryGrandSaveClass}`);
	const elmCountItem = document.querySelector(`.${DATA_SETTING.summaryTotalCountClass}`);
	
	const elmTotalPriceChoose = document.querySelector(`.section-2 .${DATA_SETTING.summaryTotalPriceChoose}`);
	const elmTotalFullPriceChoose = document.querySelector(`.section-2 .${DATA_SETTING.summaryFullPriceChoose}`);
	
	elmCountItem && (elmCountItem.innerText = countItem);
	elmSubPrice && (elmSubPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	elmSavePrice && (elmSavePrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	
	if(shipping === 0){
		elmShipPrice && (elmShipPrice.innerText = 'FREE');
	} else {
		elmShipPrice && (elmShipPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	}
	elmTotalPrice && (elmTotalPrice.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price + shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	
	elmTotalPriceChoose && (elmTotalPriceChoose.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price + shipping, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
	elmTotalFullPriceChoose && (elmTotalFullPriceChoose.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice, arrCart[0].product.productPrices.DiscountedPrice.FormattedValue));
}

// remove disable class when data loaded
function removeDisableClass(){
	const elmDisableClass = document.querySelectorAll('.disableCls');
	elmDisableClass.forEach(elm => {
		elm.classList.remove('disableCls');
	})
}



//check anf show payment button
function triggerCheckoutType(){
	const btnCheckoutCC = document.querySelector('button[name="checkoutWithCreditCardV1"]');
	const btnCheckoutPP = document.querySelector('.checkoutWithPaypal.button-choose');
	const elmTab = document.querySelector('.faq-payment');
	elmTab && elmTab.addEventListener('click', (e) => {
		setTimeout(() => {
			const elmPaypalTab = document.querySelector('.accordion__item--is-open .payment-pp');
			if (elmPaypalTab){
				btnCheckoutPP && btnCheckoutPP.classList.remove('js-hidden');
				btnCheckoutCC && btnCheckoutCC.classList.add('js-hidden');
				isPaypalPayment = true;
			} else {
				btnCheckoutPP && btnCheckoutPP.classList.add('js-hidden');
				btnCheckoutCC && btnCheckoutCC.classList.remove('js-hidden');
				isPaypalPayment = false;
			}
		},100)
	})
}





//apply coupon
function triggerCouponCode(){
	const btnCoupon = document.querySelector('.btn-couponcode');
	btnCoupon && btnCoupon.addEventListener('click', (e) => {
		e.preventDefault();
		e.stopPropagation();
		e.stopImmediatePropagation();
		
		const inputCoupon = document.querySelector('.input-couponcode');
		const msgSuccess = document.querySelector('.coupon-msg .success');
		const msgError = document.querySelector('.coupon-msg .error');
		if (!inputCoupon) return;
		msgError && (msgError.style.display = 'none');
		msgSuccess && (msgSuccess.style.display = 'none');
		if (inputCoupon.value !== couponCode){
			msgError && (msgError.style.display = 'block');
			msgSuccess && (msgSuccess.style.display = 'none');
		} else {
			window.ctrwowCheckout.checkoutData.setCouponCode(couponCode);
			msgError && (msgError.style.display = 'none');
			msgSuccess && (msgSuccess.style.display = 'block');
			bindData2OrderSummary();
		}
	});
}

//trigger shipping type
function triggerShippingExpress(){
	const elmShippingOpt = document.querySelectorAll('.delivery-opts .wrap-opts .delivery-item');
	elmShippingOpt.forEach(opt => {
		opt.addEventListener('click', () => {
			setTimeout(() => {
				bindData2OrderSummary();
			}, 100);
		})
	})
}
  
function triggerVideo() {
    const btns = document.querySelectorAll('.guide-slider .slide-item .btn-play-video');
    const popup = document.querySelector('.guide-popup');
    const closeBtn = popup.querySelector('.close-popup');
    const popupVideo = popup.querySelector('video'); 
    const playImg = popup.querySelector('.play-img');
 
    popupVideo.addEventListener('play', () => {
        if (playImg) playImg.style.display = 'none';
    });
 
    popupVideo.addEventListener('pause', () => {
        if (playImg) playImg.style.display = 'block';
    });
 
    if (playImg) {
        playImg.addEventListener('click', () => {
            popupVideo.play();
        });
    }
 
    btns.forEach((btn) => {
        btn.addEventListener('click', () => {
            const slideVideo = btn.closest('.slide-item').querySelector('video');
            if (!slideVideo || !popupVideo) return;
 
            popupVideo.src = slideVideo.currentSrc || slideVideo.src;
            popupVideo.play();
        });
    });
 
    closeBtn.addEventListener('click', () => {
        if (popupVideo) {
            popupVideo.pause();
        }
    });
}

function listener(){
	const session1 = document.querySelector(".section-1");
	const session2 = document.querySelector(".section-2");
	const btnProcess = document.querySelectorAll(".proceed-btn");

	Array.prototype.slice.call(btnProcess).forEach(item => {
		item.addEventListener("click", function(){
			// update product and price to checkout screen
			bindData2OrderSummary();
			session1 && session1.classList.add("js-hidden");
			session2 && session2.classList.remove("js-hidden");
			session2.scrollIntoView({behavior: "smooth"});
			
			//add param when change to checkoutview
			window.ctrwowUtils.handleParam.addParamIntoUrl('view','checkout');
			isCheckoutView = true;
		})
	})
	
	const btnEdits = document.querySelectorAll(".btn-edit-product");
	btnEdits.forEach(btnEdit => {
		btnEdit.addEventListener("click", function(){
			session1 && session1.classList.remove("js-hidden");
			session2 && session2.classList.add("js-hidden");
		  
			setTimeout(function(){
				isCheckoutView = false;
				const elmMiniCart = document.querySelector('.section-1 .cart-icon');
				elmMiniCart && elmMiniCart.click();
				
				const guideSlide = document.querySelector('.guide-slider .main-slider');
				guideSlide && guideSlide?.slick?.setPosition();
				
				const topSlide = document.querySelector('.top-slider .main-slider');
				topSlide && topSlide?.slick?.setPosition();
				
				
				const selectGroup = document.querySelector(".return-here");
				selectGroup && selectGroup.scrollIntoView({
					behavior: "smooth"
				});
			},200);
		})
	})
	
	
	// trigger buttin add to cart
	triggerAddToCart();
	triggerCloseMiniCart();
	triggerCheckoutType();
	triggerCouponCode();
	triggerShippingExpress();
    triggerVideo();
    // triggerSizeChange();
}

// trigger back button of browser
window.addEventListener("popstate", (event) => {
	const session2 = document.querySelector('.section-2');
	if(isCheckoutView && !session2.classList.contains('js-hidden')){
		const session1 = document.querySelector(".section-1");
		const session2 = document.querySelector(".section-2");
		const selectGroup = document.querySelector(".return-here");
		session1 && session1.classList.remove("js-hidden");
		session2 && session2.classList.add("js-hidden");
		history.pushState({}, "", location.href)
		setTimeout(function(){
			const guideSlide = document.querySelector('.guide-slider .main-slider');
			guideSlide && guideSlide?.slick?.setPosition();
			selectGroup && selectGroup.scrollIntoView({
				behavior: "smooth"
			});
		},200);
	}
	isCheckoutView = false;
});
  
//trigger click FAQ
function triggerFAQ(){
	const elmDescPros = document.querySelectorAll('.desc-pro .js-accordion__item');
    elmDescPros.forEach(item => {
        item.addEventListener('click', (e) => {
            setTimeout(() => {
                const elmOpen = document.querySelector('.desc-pro .js-accordion__item.accordion__item--is-open');
                elmOpen && elmOpen.scrollIntoView({behavior:'smooth'})
            },100);
        })
    })

	const elmAllFAQs = document.querySelectorAll('.accordion__item');
	elmAllFAQs.forEach(item => {
		if(!item.closest('.faq-payment')){
			item.addEventListener('click', (e) => {
				setTimeout(() => {
					const elmTab = document.querySelectorAll('.faq-payment .js-accordion__item');
					if(isPaypalPayment && elmTab.length > 1){
						elmTab[1].classList.add('accordion__item--is-open');
					}else if(elmTab.length > 0){
						elmTab[0].classList.add('accordion__item--is-open');
					}
				},100)
				
			})
		}
	})
}

window.addEventListener("load", () => {
    updateDiscountPercent();
	listener();
	resetSize();
    triggerFAQ();
	getAllCampaign();
});