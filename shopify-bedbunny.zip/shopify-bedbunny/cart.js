
// trigger buttin add to cart
function triggerAddToCart(){
	const elmBtnAddToCarts = document.querySelectorAll(`.${DATA_SETTING.btnAddToCart}`);
	elmBtnAddToCarts.forEach(btn => {
		btn.addEventListener('click', (e) => {
			const elmOpt1 = document.querySelector(`.${DATA_SETTING.opt1ActiveClass}`);
			const elmOpt1Img = elmOpt1.querySelector(`img.${DATA_SETTING.proImgClass}`);
			const elmOpt1Gift = elmOpt1.querySelector(`img.${DATA_SETTING.giftImgClass}`);
			// const elmOpt2 = document.querySelector(`.${DATA_SETTING.opt2ActiveClass}`);
			const opt1Value = elmOpt1?.dataset.value;
			// const opt2Value = elmOpt2?.dataset.value;
			const lblOpt1 = elmOpt1?.dataset.label;
			// const lblOpt2 = elmOpt2?.dataset.label;
			
			if(!opt1Value) return;
			const elmOpt2s =  document.querySelectorAll('.option-group .size-box .size:not(.js-hidden)')

            elmOpt2s.forEach(elmOpt2 => {
                const opt2Value = elmOpt2.querySelector('select').value;
                const lblOpt2 = opt2Value

                // const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
                const qty = 1;
                const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: qty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmOpt1Img?.src};
                const product = getProduct(productInfo, false, true);
                let countPro = 0;
			arrCart.forEach(info => {
				countPro += info.qty;
			})
                if(countPro < maxProduct){
                    const isExistsPro = arrCart.find(item => {
                        return item.opt1 === opt1Value && item.opt2 === opt2Value;
                    })
                    
                    if(!isExistsPro){
                        let newQty = qty > (maxProduct - countPro) ? maxProduct - countPro : qty
                        const productInfo = {opt1: opt1Value, opt2: opt2Value, qty: newQty, lblOpt1: lblOpt1, lblOpt2: lblOpt2, img: elmOpt1Img?.src, giftImg: elmOpt1Gift?.src};
                        const product = getProduct(productInfo, false);
                        product && arrCart.push(productInfo);
                    }else{
                        isExistsPro.qty += qty;
                        if(isExistsPro.qty > maxProduct) isExistsPro.qty = maxProduct;
                        getProduct(isExistsPro, false);
                    }
                } 

            })
			
			
			
			
			
			
			replaceCartNumberProduct();
			updateCartInfo();
			
			//reset qty
            const elmQty = document.querySelector(`.${DATA_SETTING.mainQtyClass} input`);
			elmQty && (elmQty.value = 1);
			resetSize();
			updateSizeOption();
			updateLayoutWithSelectOption(1);
			updateDiscountValue(1);
		})
	})
}

// bind price each item in mini cart
function bindPriceToLayout(product, groupItem, clsPrice, clsFullPrice, clsSave, isShowUnit = false){
	const elmPrice = groupItem.querySelectorAll(`.${clsPrice}`);
	const elmFullPrice = groupItem.querySelectorAll(`.${clsFullPrice}`);
	const elmSavePrice = groupItem.querySelectorAll(`.${clsSave}`);
	let price = null;
	let fullPrice = null;
	let priceFormat = null;
	let fullPriceFormat = null
	
	if(isShowUnit){
		price = product.productPrices?.UnitDiscountRate?.Value;
		fullPrice = product.productPrices?.UnitFullRetailPrice?.Value;
		priceFormat = product.productPrices?.UnitDiscountRate?.FormattedValue;
		fullPriceFormat = product.productPrices?.UnitFullRetailPrice?.FormattedValue
	}
	
	if(!price) price = product.productPrices.DiscountedPrice.Value;
	if(!fullPrice) fullPrice = product.productPrices.FullRetailPrice.Value;
	if(!priceFormat) priceFormat = product.productPrices.DiscountedPrice.FormattedValue;
	if(!fullPriceFormat) fullPriceFormat = product.productPrices.FullRetailPrice.FormattedValue;
	
	elmPrice.forEach(item => {
		item.innerText = priceFormat;
		item.classList.remove('loading');
	})
	
	elmSavePrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, product.productPrices.DiscountedPrice.FormattedValue);
		item.classList.remove('loading');
	})
	
	elmFullPrice.forEach(item => {
		item.innerText = fullPriceFormat;
		item.classList.remove('loading');
	})
}




// Trigger click detete product and add more item in mini cart
function triggerActionInCart(elmCartItemsParent){
	// delete button
	const btnDeleteds = elmCartItemsParent.querySelectorAll('.delete-btn');
	btnDeleteds.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if(!elmParent) return;
			const index = parseInt(elmParent.dataset.index);
			
			if(typeof index !== "undefined"){
				arrCart.splice(index, 1);
				replaceCartNumberProduct();
				updateCartInfo();
			}
		})
	})
	
	// add more  button
	const btnPlus = elmCartItemsParent.querySelectorAll('span.plus');
	btnPlus.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if (!elmParent) return;
			
			const elmQty = elmParent.querySelector('input.numberTxt');
			let qty = elmQty ? parseInt(elmQty.value) : null;
			const index = parseInt(elmParent.dataset.index);
			
			let countPro = 0;
			arrCart.forEach(info => {
				countPro += info.qty;
			})
			
			if(!qty || qty === maxProduct || typeof index === "undefined" || countPro >= maxProduct) return;
			qty += 1;
			const productInfo = arrCart[index];
			
			if(!productInfo) return;
			productInfo.qty = qty;
			getProduct(productInfo, false);
			replaceCartNumberProduct();
			updateCartInfo();
		})
	})
	
	const btnMinus = elmCartItemsParent.querySelectorAll('span.minus');
	btnMinus.forEach(btn => {
		btn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			e.stopImmediatePropagation();
			const elmParent = e.currentTarget.closest('.cart-item');
			if (!elmParent) return;
			
			const elmQty = elmParent.querySelector('input.numberTxt');
			let qty = elmQty ? parseInt(elmQty.value) : null;
			const index = parseInt(elmParent.dataset.index);
			
			if(!qty || qty === 1 || typeof index === "undefined") return;
			qty -= 1;
			const productInfo = arrCart[index];
			
			if(!productInfo) return;
			productInfo.qty = qty;
			getProduct(productInfo, false);
			replaceCartNumberProduct();
			updateCartInfo();
		})
	})
}

// update each item in mini cart
function bindData2CartItem(info, cartItem, itemIndex){
	if(!info || !info.product) return;
	cartItem.dataset.index = itemIndex;
	const elmSources = cartItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} picture source`);
	elmSources.forEach(source => {
		source.remove();
	});
	
	const img = cartItem.querySelector(`.${DATA_SETTING.cartImgClass} img`);
	if(img){
		img.removeAttribute('data-srcsets');
		img.removeAttribute('data-lazy-srcsets');
		img.setAttribute('src', info?.img);
	}
	
	const elmOpt1Desc = cartItem.querySelector(`.${DATA_SETTING.cartOpt1Desc}`);
	elmOpt1Desc && (elmOpt1Desc.innerText = info?.lblOpt1);
	
	const elmOpt2Desc = cartItem.querySelector(`.${DATA_SETTING.cartOpt2Desc}`);
	elmOpt2Desc && (elmOpt2Desc.innerText = info?.lblOpt2);
	
	const elmQty = cartItem.querySelector(`.${DATA_SETTING.cartItemQtyClass}`);
	elmQty && (elmQty.value = info?.qty);
	
	const elmSumQty = cartItem.querySelector(`.${DATA_SETTING.cartSumItemClass}`);
	elmSumQty && (elmSumQty.innerText = info?.qty);
	
	const elmSumPrice = cartItem.querySelector(`.${DATA_SETTING.cartSumPriceItemClass}`);
	elmSumPrice && (elmSumPrice.innerText = info.product.productPrices.DiscountedPrice.FormattedValue);
	
	const elmMaxQtyMsg = cartItem.querySelector(`.${DATA_SETTING.cartMessMaxQty}`);
	elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
	if (info && info.qty === 5){
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.remove('js-hidden'));
	}
	
	//bind price each item in mini cart
	bindPriceToLayout(info.product, cartItem , DATA_SETTING.cartItemDiscountPriceClass, DATA_SETTING.cartItemFullPriceClass, DATA_SETTING.cartItemSavePriceClass, false);
}

function bindData2CartGift(info, cartGiftItem){
	if(!info || !info.product) return;
	const elmSources = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} picture source`);
	elmSources.forEach(source => {
		source.remove();
	});
	
	const isExistImgs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt1ShowClass}.${info?.lblOpt1?.toLocaleLowerCase().replace(/ /g,'-')}`) || cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartGiftGroupClass} .${DATA_SETTING.opt2ShowClass}.${info?.lblOpt2?.toLocaleLowerCase().replace(/ /g,'-')}`);
	if (isExistImgs.length > 0){
		const allImgs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt1ShowClass}`) || cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartImgClass} .${DATA_SETTING.opt2ShowClass}`);
		allImgs.forEach(img => {
			img.classList.add('js-hidden');
		})
		isExistImgs.forEach(img => {
			img.classList.remove('js-hidden');
		}) 
	}else{
		const img = cartGiftItem.querySelector(`.${DATA_SETTING.cartImgClass} img`);
		if(img){
			img.removeAttribute('data-srcsets');
			img.removeAttribute('data-lazy-srcsets');
			img.setAttribute('src', info?.giftImg);
		}
	}
	
	
	const elmOpt1Descs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartOpt1Desc}`);
	elmOpt1Descs.forEach(elmOpt1Desc => {
		elmOpt1Desc.innerText = info?.lblOpt1;
	})
	
	const elmOpt2Descs = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartOpt2Desc}`);
	elmOpt2Descs.forEach(elmOpt2Desc => {
		elmOpt2Desc.innerText = info?.lblOpt2
	})
	
	const elmQtys = cartGiftItem.querySelectorAll(`.${DATA_SETTING.cartItemQtyClass}`);
	elmQtys.forEach(elmQty => {
		elmQty.value = info?.qty;
	})
	
	const elmSumQtys = cartGiftItem.querySelectorAll(`.${DATA_SETTING.summaryItemQtyClass}`);
	elmSumQtys.forEach(elmSumQty => {
		elmSumQty.innerText = info?.qty;
	})
	
	const elmFullPrice = cartGiftItem.querySelectorAll(`.addon-fullprice`);
	const elmPrice = cartGiftItem.querySelectorAll(`.addon-price`);
	elmFullPrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(giftPrice * info?.qty, info.product.productPrices.DiscountedPrice.FormattedValue);
	})
	
	elmPrice.forEach(item => {
		item.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(0, info.product.productPrices.DiscountedPrice.FormattedValue);
	})
	
}

function updateTotalPrice4MiniCart(price, fullPrice){
	const elmCartContent = document.querySelector(`.${DATA_SETTING.cartContentClass}`);
	const elmTotalFullPrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalFullPriceClass}`);
	const elmTotalPrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalPriceClass}`);
	const elmTotalSavePrice = elmCartContent.querySelectorAll(`.${DATA_SETTING.cartTotalSavePriceClass}`);
	
	const mini = window.ctrwowCheckout.checkoutData.getMiniUpsell() || [];
	mini.forEach(item => {
		price += item.productPrices.DiscountedPrice.Value;
		fullPrice += item.productPrices.FullRetailPrice.Value;
	})
	
	elmTotalFullPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
	elmTotalPrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(price, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
	elmTotalSavePrice.forEach(elm => {
		elm.classList.remove('loading');
		elm.innerText = window.ctrwowUtils.number.formaterNumberByFormattedValue(fullPrice - price, window.ctrwowCheckout.checkoutData.getProduct().productPrices.DiscountedPrice.FormattedValue);
	})
}

//show discount percent
function displayDiscountPercent(){
	let totalQty = 0;
	arrCart.forEach(item => {
		totalQty += item.qty;
	})
	
	if(totalQty === 0) totalQty = 1;
	
	const elmDiscount = document.querySelectorAll(`.${DATA_SETTING.cartContentClass} .${DATA_SETTING.cartDiscountMessClass}`);
	elmDiscount.forEach((item, index) => {
		item.classList.add('js-hidden');
		if(index + 1 === totalQty){
			item.classList.remove('js-hidden');
		}
		
	});
}


function reUpdateProFollowCampaign(){
	let totalQty = 0;
	arrCart.forEach(info => {
		getProduct(info, false);
	})
}

// update cart icon number and mini card info
function updateCartInfo(){
	const elmCartContent = document.querySelector(`.${DATA_SETTING.cartContentClass}`);
	const elmCartPro = elmCartContent.querySelector(`.${DATA_SETTING.cartProductClass}`);
	const elmCartItemsParent = elmCartPro.querySelector(`.${DATA_SETTING.cartItemsClass}`);
	
	const elmBtnProceed = elmCartContent.querySelector(`.${DATA_SETTING.btnProcessClass}`);
	!elmCartItemTemplate && (elmCartItemTemplate = elmCartItemsParent.querySelector(`.${DATA_SETTING.cartItemClass}`).cloneNode(true));
	
	const elmCartGiftParent = elmCartContent.querySelector(`.${DATA_SETTING.cartGiftGroupClass}`);
	//!elmGiftItemTemplate && (elmGiftItemTemplate = elmCartGiftParent.querySelector(`.${DATA_SETTING.cartGiftItemClass}`).cloneNode(true));
	!elmGiftItemTemplate && (elmGiftItemTemplate = elmCartGiftParent.cloneNode(true));
	
	const elmMaxQtyMsg = document.querySelector(`.${DATA_SETTING.cartMessMaxQty}`);
	
	//show discount message
	displayDiscountPercent();
	
	//update cart count
	replaceCartNumberProduct();
	
	if(arrCart.length === 0){
		elmCartPro && elmCartPro.classList.add('js-hidden');
		elmCartGiftParent && elmCartGiftParent.classList.add('js-hidden');
		elmBtnProceed && elmBtnProceed.classList.add('disableCls');
		let price = 0, fullPrice = 0;
		//update total price
		updateTotalPrice4MiniCart(price,fullPrice);
		
		//hide message
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
	} else {
		//update shipping price follow campaign
		reUpdateProFollowCampaign();
		
		//update insurance follow qty
        reCalInsurancePrice();
		
		elmCartPro && elmCartPro.classList.remove('js-hidden');
		elmCartGiftParent && elmCartGiftParent.classList.remove('js-hidden');
		elmBtnProceed && elmBtnProceed.classList.remove('disableCls');
		let price = 0, fullPrice = 0;
		
		elmCartItemsParent.innerHTML = '';
		const firstTemp = elmCartItemTemplate.cloneNode(true);
		bindData2CartItem(arrCart[0], firstTemp, 0);
		elmCartItemsParent.appendChild(firstTemp);
		price += arrCart[0].product.productPrices.DiscountedPrice.Value;
		fullPrice += arrCart[0].product.productPrices.FullRetailPrice.Value;
		
		//for gift
		elmCartGiftParent.innerHTML = '';
		const firstGiftTemp = elmGiftItemTemplate.cloneNode(true);
		bindData2CartGift(arrCart[0], firstGiftTemp);
		elmCartGiftParent.appendChild(firstGiftTemp);
		fullPrice += (giftPrice * arrCart[0].qty)*2;
		
		for(let i= 1; i < arrCart.length; i++){
			const info = arrCart[i];
			const temp = elmCartItemTemplate.cloneNode(true);
			bindData2CartItem(info, temp, i);
			elmCartItemsParent.appendChild(temp);
			price += info.product.productPrices.DiscountedPrice.Value;
			fullPrice += info.product.productPrices.FullRetailPrice.Value;
			
			//for gift
			const giftTemp = elmGiftItemTemplate.cloneNode(true);
			bindData2CartGift(info, giftTemp);
			elmCartGiftParent.appendChild(giftTemp);
			fullPrice += (giftPrice * info.qty)*2;
		}
		
		//update total price
		updateTotalPrice4MiniCart(price,fullPrice);
	
		// Trigger click detete product and add more item in mini cart
		triggerActionInCart(elmCartItemsParent);
		
		//detect show message
		elmMaxQtyMsg && (elmMaxQtyMsg.classList.add('js-hidden'));
		let countQty = 0;
		arrCart.forEach(p => {
			countQty += p.qty;
		})
		if (countQty >= 4){
			elmMaxQtyMsg && (elmMaxQtyMsg.classList.remove('js-hidden'));
		}
	}
}




// update cart number in cart icon
function replaceCartNumberProduct(){
	
	const elmCartCount = document.querySelectorAll('.cart-count');
	let countPro = 0;
	arrCart.forEach(info => {
		countPro += info.qty;
	})
	
	// count gift
	countPro = countPro*3;
	
	//count mini
	window.ctrwowCheckout.checkoutData.getMiniUpsell().forEach(item => {
		countPro += 1
	})
	
	if(arrCart.length === 0){
		countPro = 0;
	}
	
	elmCartCount.forEach(elm => {
		elm.textContent = countPro;
	})
	
	const elmMaxQtyMess = document.querySelector(`.${DATA_SETTING.cartContentClass} .${DATA_SETTING.maxTotalQtyMessClass}`);
	elmMaxQtyMess && elmMaxQtyMess.classList.add('js-hidden');
	if (countPro === maxProduct) {
		elmMaxQtyMess && elmMaxQtyMess.classList.remove('js-hidden');
	}
    const qtyGifts = document.querySelectorAll('.qty-gift') 
    qtyGifts.forEach(elm => {
        elm.innerText = countPro;

    })
    const qtyGiftCarts = document.querySelectorAll('.qty-gift-cart input') 
    qtyGiftCarts.forEach(elm => {
        elm.value = countPro;
        
    })
}

function triggerCloseMiniCart(){
	const elmCartContent = document.querySelector(".cart-popup .cart-content");
	const elmPopup = document.querySelector('.cart-popup .popup_widget');
	elmPopup && elmPopup.addEventListener("click", (e) => {
	  if (!elmCartContent.contains(e.target)) {
		elmPopup.classList.remove('popup_widget--opened');
		document.querySelector('body').classList.remove('show-popup_widget');
	  }
	});
}

// show/hide mini cart
function triggerCartIconClick(){
	const emlCartIcon = document.querySelector('.cart-icon');
	emlCartIcon && emlCartIcon.addEventListener('click', () => {
		updateCartInfo();
	})
}
