
// Function for new feature: change PID when change size

function getAllCampaign() {
    const headers = {method: "GET",X_CID: XCID,"Content-Type": "application/json"};
    const webkeys = [webkey2Units, webkey3Units, webkey4Units];
	if (loadProductMini) {
		Promise.all(
			webkeys.map(key =>
				Promise.all([
					fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices`, { headers }).then(res => res.json()),
					fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices/miniupsells`, { headers }).then(res => res.json())
				])
			)
		)
		.then((results) => {
			// results: [ [prices2, upsells2], [prices3, upsells3], [prices4, upsells4] ]
			const [[prices2, upsells2], [prices3, upsells3], [prices4, upsells4]] = results;
			if(ratioQty){
			  prices2.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			  prices3.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			  prices4.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
			  })
			}

			campaign2Info = prices2;
			mini2Info = upsells2;

			campaign3Info = prices3;
			mini3Info = upsells3;

			campaign4Info = prices4;
			mini4Info = upsells4;

			getPriceWithOptionSelect();
		})
		.catch(err => { console.log("get all campaign error:", err); });
	} else {
		Promise.all(
			webkeys.map(key =>
				fetch(`https://prices.tryemanagecrm.com/api/campaigns/${key}/products/prices`, { headers }).then(res => res.json())
			)
		)
		.then(([info2, info3, info4]) => {
			if(ratioQty){
				info2.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
				})
				info3.prices.forEach(item => {
					item.quantity = item.quantity/ratioQty;
				})
				info4.prices.forEach(item => {
				  item.quantity = item.quantity/ratioQty;
				})
			}
			campaign2Info = info2;
			campaign3Info = info3;
			campaign4Info = info4;
			getPriceWithOptionSelect();
		}).catch(err => { console.log("get all campaign error: " + err); });
	}
}

function updateAllPrice(campaign, couponType, couponValue){
	if(!campaign) return;
	campaign.prices.forEach(pro => {
		if (couponType === 'percent'){
			const calculatePrice = (pro.productPrices.DiscountedPrice.Value * (1 - couponValue / 100)).toFixed(2);
			pro.productPrices.DiscountedPrice.Value = Number(calculatePrice);
			pro.productPrices.DiscountedPrice.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				pro.productPrices.DiscountedPrice.Value,
				pro.productPrices.DiscountedPrice.FormattedValue
			)
			
			if (pro.productPrices.UnitDiscountRate){
				const calculateUnitPrice = (pro.productPrices.UnitDiscountRate.Value * (1 - couponValue / 100)).toFixed(2)
				pro.productPrices.UnitDiscountRate.Value = Number(calculateUnitPrice)
				pro.productPrices.UnitDiscountRate.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				  pro.productPrices.UnitDiscountRate.Value,
				  pro.productPrices.UnitDiscountRate.FormattedValue
				)
			}
		} else {
			let newDiscountPrice = Number((elm.productPrices.DiscountedPrice.Value - couponValue).toFixed(2))
			let newUnitDiscountPrice = 0
			if (elm.productPrices.UnitDiscountRate) {
				newUnitDiscountPrice = Number((elm.productPrices.UnitDiscountRate.Value - couponValue / elm.quantity).toFixed(2))
			}
			if (isKasheeCoupon) {
				const itemDefault = priceDefaults.find((item) => item.productId === elm.productId)
				newDiscountPrice = Number((itemDefault.productPrices.DiscountedPrice.Value - couponValue).toFixed(2))
				if (elm.productPrices.UnitDiscountRate) {
				newUnitDiscountPrice = Number((itemDefault.productPrices.UnitDiscountRate.Value - couponValue / elm.quantity).toFixed(2))
				}
			}
			elm.productPrices.DiscountedPrice.Value = newDiscountPrice > 0 ? newDiscountPrice : 0
			elm.productPrices.DiscountedPrice.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				elm.productPrices.DiscountedPrice.Value,
				elm.productPrices.DiscountedPrice.FormattedValue
			)

			if (elm.productPrices.UnitDiscountRate) {
				elm.productPrices.UnitDiscountRate.Value = newUnitDiscountPrice > 0 ? newUnitDiscountPrice : 0
				elm.productPrices.UnitDiscountRate.FormattedValue = window.ctrwowUtils.number.formaterNumberByFormattedValue(
				elm.productPrices.UnitDiscountRate.Value,
				elm.productPrices.UnitDiscountRate.FormattedValue
				)
			}
		}
	})
}

function updateAllCampaignWithCoupon(){
	const elmExitPopup = document.querySelector("div[couponvalue]");
	if (!elmExitPopup || isApplyCoupon) return;
	
	const couponValue = elmExitPopup.getAttribute("couponvalue") ? parseInt(elmExitPopup.getAttribute("couponvalue")) : 0
	const couponType = elmExitPopup.getAttribute("coupontype") || 'percent';
	updateAllPrice(campaign2Info, couponType, couponValue);
	updateAllPrice(campaign3Info, couponType, couponValue);
	updateAllPrice(campaign4Info, couponType, couponValue);
	isApplyCoupon = true;
	setTimeout(() => {
	  const qty = parseInt(document.querySelector('.main-screen .numberTxt').value)
	  updateDiscountValue(qty);
	}, 200)
}
