
const purchaseDropdownOptionClass1 = 'size-dropdown';
const purchaseDropdownOptionClass2 = 'color-dropdown';
let arrSizePurchase = [];
const purchasePriceClass = 'additionPrice-4pro';
const currentPrice = {};
const arrCart = [];
let elmCartItemTemplate = null, elmGiftItemTemplate = null;
let elmSummaryItemTemplate = null, elmSummaryGiftItemTemplate = null;
const couponCode = '';
let isCheckoutView = false, isApplyCoupon = false;
const loadProductMini = false;
let isPaypalPayment = false;
const ratioQty = 1;
const maxProduct = 4;
const giftPrice = 19.99; //($80)
let campaign2Info, campaign3Info, campaign4Info, mini2Info, mini3Info, mini4Info;
const 	XCID = '4405f5f3-eb46-46bd-8d96-f17f2c7d8c0d',
		webkey2Units = 'CF7D126D-471B-4091-A87F-B4606908B4E8',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/159
		webkey3Units = '6E8B6818-0371-4032-98DF-C35082DFAC47',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/160
		webkey4Units = 'E1F23D63-6B03-4FDF-A573-510A0FF0DB94',//https://telebrands.tryemanagecrm.com/#/campaigns/settings/161
		shippingIds = {	webkey2Units: {1: 10044, 2: 10045},
					webkey3Units: {1: 10044, 2: 10045, 3: 10046},
					webkey4Units: {1: 10044, 2: 10045, 3: 10046, 4: 10047}};
					
const DATA_SETTING = {
	proImgClass: 'pro-img',
	giftImgClass: 'gift-img',
	opt1Class: 'color-option',
	opt1ShowClass: 'color-show',
	opt1ActiveClass: 'color-option.active',
	opt1LabelClass: 'color-text-choose',
	stickyBarOpt1Class: 'color-bottom',
	stickyBarOpt1DropdownClass: 'color-dropdown-bottom',
	opt1Value: 'White, Cream, Gray', // follow product name on CRM
	opt1Label: 'White, Cream, Gray',
	bracketsOpt1Begin: '(', // follow product name format
	bracketsOpt1End: ')', // follow product name format
	opt2Class: 'size-option',
	opt2ShowClass: 'size-show',
	opt2ActiveClass: 'size-option.active',
	opt2LabelClass: 'size-text-choose',
	stickyBarOpt2Class: 'size-bottom',
	stickyBarOpt2DropdownClass: 'size-dropdown-bottom',
	opt2Value: 'Twin, Full, Queen, King', // follow product name on CRM
	opt2Label: 'TWIN - 39" x 75" x 15", FULL - 54" x 75" x 15", QUEEN - 60" x 80" x 15", KING - 76" x 80" x 15"',
	bracketsOpt2Begin: '(', // follow product name format
	bracketsOpt2End: ')', // follow product name format
	mainQtyClass: 'main-screen',
	priceMain1UnitClass: 'discount-price-choose', // show on floating bar screen
	fullPriceMain1UnitClass: 'full-price-choose', // show on floating bar screen
	savePriceMain1UnitClass: 'saving-price-choose', // show on floating bar screen
	totalPriceMainScreenClass: 'total-main-price-choose', // show on main screen
	totalFullPriceMainScreenClass: 'total-main-fullprice-choose', // show on main screen
	totalSavePriceMainScreenClass: 'total-main-saveprice-choose', // show on main screen
	cartContentClass: 'cart-content', 
	cartProductClass: 'cart-pro',
	cartItemsClass: 'cart-items',
	cartItemClass: 'cart-item',
	cartOpt1Desc: 'color-desc',
	cartOpt2Desc: 'size-desc',
	cartImgClass: 'cart-image',
	cartItemQtyClass: 'numberTxt',
	cartSumItemClass: 'sum-item-count',
	cartSumPriceItemClass: 'sum-item-price',
	cartMessMaxQty: 'max-qty-msg',
	cartItemDiscountPriceClass: 'cart-discount-price-choose',
	cartItemFullPriceClass: 'cart-full-price-choose',
	cartItemSavePriceClass: 'cart-saving-price-choose',
	cartGiftGroupClass: 'gift-group',
	cartGiftItemClass: 'pro-gift',
	cartTotalFullPriceClass: 'total-fullprice-choose',
	cartTotalPriceClass: 'total-price-choose',
	cartTotalSavePriceClass: 'total-saveprice-choose',
	cartDiscountMessClass: 'discount',
	cartInsureshipContentClass: 'cart-insureship',
	btnProcessClass: 'proceed-btn',
	btnAddToCart: 'btn-addtocart',
	maxTotalQtyMessClass: 'max-total-qty-msg',
	summaryGroupClass: 'pro-info',
	summaryItemsProductClass: 'summary-items',
	summaryItemProductClass: 'sum-item',
	summaryGiftGroupClass: 'gift-group',
	summaryGiftItemClass: 'sum-gift',
	summarySubTotalClass: 'js-sum-sub-total',
	summaryShippingPriceClass: 'js-sum-shipping-price',
	summaryFullPriceClass: 'js-sum-full-price',
	summaryGrandSaveClass: 'js-grand-save',
	summaryTotalCountClass: 'sum-total-count',
	summaryTotalPriceChoose: 'sum-total-price-choose',
	summaryFullPriceChoose: 'sum-total-fullprice-choose',
	summaryItemQtyClass: 'sum-numberTxt',
	summarySafeTrakPriceClass: 'js-price-safetrak'
}
