const maxProduct = 4;


//  Choose Product's Color

function  selectProductColor(){
    const elmOptColors = document.querySelectorAll('.color-options .color-picker');
    const elmTextColor = document.querySelector('.color-text-choose');

    elmOptColors.forEach((elmOptColor)=>{
        elmOptColor.addEventListener(('click'),(e)=>{
            elmOptColors.forEach((elm)=>{
                elm.classList.remove('active')
            })
            e.currentTarget.classList.add('active')
            elmTextColor.innerText = elmOptColor.dataset.value
        })
    })
}
selectProductColor()

function triggerAddRemoveItemOnMain() {
    const buttons = document.querySelectorAll('.product-detail .plus, .product-detail  .minus');

    buttons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();

            const elmParent = e.currentTarget.closest('.quantity-control');
            const elmQty = elmParent?.querySelector('input.qty-input');
            if (!elmQty) return;

            let qty = parseInt(elmQty.value) || 0;
            const isPlus = e.currentTarget.classList.contains('plus');

            if (isPlus) {
                if (qty >= maxProduct) return;
                qty++;
            } else {
                if (qty <= 1) return;
                qty--;
            }

            elmQty.value = qty;
            // updateSizeOption();
            // updateLayoutWithSelectOption(qty);
            // updateDiscountValue(qty);
        });
    });
}

triggerAddRemoveItemOnMain()